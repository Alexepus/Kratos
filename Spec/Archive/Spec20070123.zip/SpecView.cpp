// SpecView.cpp : implementation of the CSpecView class
//

#include "stdafx.h"
#include "Spec.h"
#include "HSChart\\ChartCtrl.h"
#include "ReportCtrl.h"
#include "MassSpecDoc.h"
#include "SpecView.h"
#include "LogToFile.h"
#include "Approx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace std;
/////////////////////////////////////////////////////////////////////////////
// CSpecView

IMPLEMENT_DYNCREATE(CSpecView, CView)

BEGIN_MESSAGE_MAP(CSpecView, CView)
	//{{AFX_MSG_MAP(CSpecView)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_VIEW_MASSES, OnViewMasses)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MASSES, OnUpdateViewMasses)
	ON_COMMAND(ID_SETTINGS_CALIBRATION, OnSettingsCalibration)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_MESSAGE(WM_ON_CHKBOX, OnListCheckBox)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpecView construction/destruction

CSpecView::CSpecView()
{
	m_bShowList.Describe(TRUE,"View","ShowList");
	m_iListWidth.Describe(100,"View","ListWidth");
	m_bWasLButtonDown=FALSE;
	m_bCalibration=FALSE;
	m_hCursorDivSize=AfxGetApp()->LoadCursor(IDC_CURSOR_DIVSIZE);
}

CSpecView::~CSpecView()
{
	delete m_pChart;
	delete m_pList;
}

BOOL CSpecView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView drawing

void CSpecView::OnDraw(CDC* pDC)
{
	CMassSpecDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	DrawDivider(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView printing

BOOL CSpecView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSpecView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CSpecView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView diagnostics

#ifdef _DEBUG
void CSpecView::AssertValid() const
{
	CView::AssertValid();
}

void CSpecView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMassSpecDoc* CSpecView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMassSpecDoc)));
	return (CMassSpecDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSpecView message handlers

BOOL CSpecView::OnEraseBkgnd(CDC* pDC) 
{
	return 0;//CView::OnEraseBkgnd(pDC);
}

void CSpecView::OnSize(UINT nType, int cx, int cy) 
{
	if(nType!=SIZE_RESTORED)
		return;
	CView::OnSize(nType, cx, cy);
	ResizeClient(cx,cy);
}

int CSpecView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	//SetTimer(1,1000,NULL);
	RECT rect={50,50,100,100};
	GetClientRect(&rect);
	m_pChart=new CChartCtrl;
	m_pChart->Create(this,rect,ID_CHART,
		WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE);//|WS_HSCROLL|WS_VSCROLL,
	m_pChart->SetEdgeType(0);//BDR_RAISEDOUTER
	m_pChart->GetBottomAxis()->SetMinMax(0,50);
	//m_pChart->AddCursor()->SetCoord(5.);
	//m_pChart->AddCursor()->SetCoord(3.);
	//m_pChart->AddCursor()->SetCoord(7.);

	m_pList=new CReportCtrl;
	m_pList->Create(this, ID_LIST, &rect);
	m_pList->ModifyStyle(0,LVS_SHOWSELALWAYS | WS_BORDER | WS_TABSTOP);
	m_pList->SetExtendedStyle(LVS_EX_GRIDLINES);
	m_pList->SetCheckboxeStyle();
	m_pList->InsertColumn(0,"Mass", LVCFMT_LEFT,100);
	m_pList->InsertItem(0,"18");
	m_pList->SetEditable(TRUE,-1,0);

	m_pCalibDlg=new CCalibDlg;
	m_pCalibDlg->Create(IDD_CALIB_DLG, this);
	m_pCalibDlg->m_pSpecView=this;

	double x[5], y[5];
	x[0]=600e6; x[1]=600e6+1; x[2]=600e6+2;
	y[0]=160;   y[1]=160.5;   y[2]=161;
	double a=FindXApproxLine(x, y, 3, 160.);
	double b=FindXApproxLine(x, y, 3, 160.5);
	double c=FindXApproxLine(x, y, 3, 161);

	return 0;
}

/*void CSpecView::OnLButtonClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rect=m_rDivider;
	rect.InflateRect(1,0);
	if(rect.PtInRect(point))
	{
		m_bShowList=FALSE;
		RECT rect={50,50,200,200};
		GetClientRect(&rect);
		OnSize(SIZE_RESTORED,rect.right, rect.bottom);
		UpdateWindow();

	}
	CView::OnLButtonDblClk(nFlags, point);
}*/

void CSpecView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_bWasLButtonDown)
	{
		CRect rect;
		GetClientRect(&rect);
		m_iListWidth=m_iListWidth.iVal+m_LastPoint.x-point.x;
		m_LastPoint=point;
		if(m_iListWidth.iVal<0)
		{
			m_iListWidth.iVal=0;
			m_LastPoint.x=rect.Width()-3;
		}
		if(m_iListWidth.iVal>rect.Width()-5)
		{
			m_iListWidth.iVal=rect.Width()-5;
			m_LastPoint.x=3;
		}

		ResizeClient();
		UpdateWindow();
	}
	else
	{
		if(m_rDivider.PtInRect(point))
			SetCursor(m_hCursorDivSize);
		//else
			////SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));
	}
	CView::OnMouseMove(nFlags, point);
}

void CSpecView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_ClickPoint=point;
	m_LastPoint=point;

	if(m_rDivider.PtInRect(point))
	{
		SetCapture();
		SetCursor(m_hCursorDivSize);
		m_bWasLButtonDown=TRUE;
	}
	CView::OnLButtonUp(nFlags, point);
}

void CSpecView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_rDivider.PtInRect(point)&&m_rDivider.PtInRect(m_ClickPoint) && 
		(abs(m_ClickPoint.x-point.x)<=1) && (abs(m_ClickPoint.y-point.y)<=1))
	{
		m_bShowList=FALSE;
		ResizeClient();
		UpdateWindow();
	}
	m_bWasLButtonDown=FALSE;
	ReleaseCapture();
	CView::OnLButtonDown(nFlags, point);
}

void CSpecView::OnViewMasses() 
{
	m_bShowList=!(BOOL)m_bShowList;
	RECT rect={50,50,200,200};
	ResizeClient();
	UpdateWindow();

}

void CSpecView::OnUpdateViewMasses(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bShowList);
}

void CSpecView::ResizeClient(int x, int y)
{
	//����� ������� ���������� ������� �������������
	if(x==-1 && y==-1)
	{
		RECT rect;
		GetClientRect(&rect);
		x=rect.right;
		y=rect.bottom;
	}
	if(m_bCalibration)
	{
		m_rDivider.right=x-m_iListWidth.iVal;
		m_rDivider.left=m_rDivider.right-5;
		m_rDivider.top=0;
		m_rDivider.bottom=y;
		m_pList->ShowWindow(SW_HIDE);
		m_CalibDlgRect.left=m_rDivider.right;
		m_CalibDlgRect.top=0;
		m_CalibDlgRect.right=x;
		m_CalibDlgRect.bottom=y;
		m_pCalibDlg->MoveWindow(m_CalibDlgRect);
		m_pCalibDlg->ShowWindow(SW_SHOW);
		DrawDivider();
		UpdateWindow();
	}
	else if((BOOL)m_bShowList)
	{
		m_pCalibDlg->ShowWindow(SW_HIDE);
		m_rDivider.right=x-m_iListWidth.iVal;
		m_rDivider.left=m_rDivider.right-5;
		m_rDivider.top=0;
		m_rDivider.bottom=y;
		m_pList->ShowWindow(SW_SHOW);
		//m_pList->SetFocus();
		m_pList->MoveWindow(m_rDivider.right,0,x-m_rDivider.right,y);
		DrawDivider();
	}
	else
	{
		m_pCalibDlg->ShowWindow(SW_HIDE);
		m_pList->ShowWindow(SW_HIDE);
		m_rDivider.right=x;
		m_rDivider.left=m_rDivider.right;
		//m_pButtonOK->ShowWindow(SW_HIDE);
	}
	m_pChart->MoveWindow(0,0,m_rDivider.left,y);
}

void CSpecView::DrawDivider(CDC *pDC)
{
	if(pDC==NULL)
		pDC=GetDC();
	if(m_rDivider.Width()>0)
	{
		CBrush NewBrush(GetSysColor(COLOR_BTNFACE));
		CPen NewPen(PS_SOLID,1,GetSysColor(COLOR_BTNFACE));
		CBrush *pOldBrush=pDC->SelectObject(&NewBrush);
		CPen *pOldPen=pDC->SelectObject(&NewPen);

		pDC->Rectangle(m_rDivider);
		m_rDivider.bottom+=1;m_rDivider.top-=1;
		pDC->Draw3dRect(m_rDivider.left,m_rDivider.top-1,m_rDivider.Width(),m_rDivider.Height()+2,GetSysColor(COLOR_3DHILIGHT),GetSysColor(COLOR_BTNSHADOW));
		pDC->SelectObject(pOldBrush);
		pDC->SelectObject(pOldPen);
	}

}

BOOL CSpecView::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	int wNotifyCode = HIWORD(wParam); // notification code 
	int wID = LOWORD(wParam);         // item, control, or accelerator identifier 
	HWND hwndCtl = (HWND) lParam;      // handle of control
	int a=0;
	switch (wID)
	{
	case ID_CHART:
		break;
	case ID_LIST:
		break;
	}
//MessageBeep(MB_ICONQUESTION);

	return CView::OnCommand(wParam, lParam);
}

void CSpecView::OnSettingsCalibration() 
{
	m_bCalibration=TRUE;
	ResizeClient();
}

void CSpecView::OnButtonCalibOK()
{
	m_bCalibration=FALSE;
	ResizeClient();

}



BOOL CSpecView::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	NMHDR *pnmh = (LPNMHDR) lParam;
	if(pnmh->code==NM_CLICK)//||pnmh->code==NM_SETFOCUS
	{
		LPNMITEMACTIVATE lpnmitem = (LPNMITEMACTIVATE) pnmh;
		if(lpnmitem->iItem<0 && lpnmitem->iSubItem>=0)
		{	int Items=m_pList->GetItemCount();
			m_pList->InsertItem(Items,"");
			m_pList->SetItemState(Items, LVIS_FOCUSED|LVIS_SELECTED, LVIS_FOCUSED|LVIS_SELECTED); 
		}
	}
	if(pnmh->code==LVN_KEYDOWN)
	{
		LV_KEYDOWN* pLVKeyDown = (LV_KEYDOWN*)lParam;

		if((pLVKeyDown->wVKey==VK_DELETE) && !m_pList->IsUnderEdit())
		{
			for(int i=0; i<m_pList->GetItemCount(); i++)
				if((m_pList->GetItemStates(i)&(RC_ITEM_FOCUSED|RC_ITEM_SELECTED))==(RC_ITEM_FOCUSED|RC_ITEM_SELECTED))
				{
					m_pList->DeleteItem(i);
					break;
				}
		}
		*pResult = 0;
	}
//LogFileFormat("hwndFrom:0x%X, idFrom:%i, code:%i", pnmh->hwndFrom, pnmh->idFrom, pnmh->code);
	return CView::OnNotify(wParam, lParam, pResult);
}

LRESULT CSpecView::OnListCheckBox(WPARAM WParam, LPARAM LParam)
{
//MessageBeep(MB_ICONQUESTION);
 return (LRESULT)0;
} 

void CSpecView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	LogFileFormat("Capture=0x%X, View hWnd=%x, List hWnd=%x, Graph hWnd=%x", (GetCapture()==0)?0:GetCapture()->m_hWnd,m_hWnd, m_pList->m_hWnd, m_pChart->m_hWnd);
	
	CView::OnTimer(nIDEvent);
}

void CSpecView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	//m_pCalibDlg->FillTable();	
}
