// MassSpecDoc.h : interface of the CMassSpecDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MASSSPECDOC_H__8FFCCC3D_56B4_4279_8DBA_DA3687C1BB51__INCLUDED_)
#define AFX_MASSSPECDOC_H__8FFCCC3D_56B4_4279_8DBA_DA3687C1BB51__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#define MAX_MASS_COUNT 50

class CMassTable
{
public:
	int Mass;
	bool Checked;
	int Code;          //��� ��� ��� ����������
	char Comments[64]; //��� ���� ������� (�.�. � ����������)
};

class CMassSpecDoc : public CDocument
{
protected: // create from serialization only
	CMassSpecDoc();
	DECLARE_DYNCREATE(CMassSpecDoc)

// Attributes
public:
	std::vector<CMassTable> m_MassTable;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMassSpecDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SaveDefMassTable();
	void InitDoc();
	virtual ~CMassSpecDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMassSpecDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MASSSPECDOC_H__8FFCCC3D_56B4_4279_8DBA_DA3687C1BB51__INCLUDED_)
