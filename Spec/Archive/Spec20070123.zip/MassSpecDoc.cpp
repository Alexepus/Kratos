// MassSpecDoc.cpp : implementation of the CMassSpecDoc class
//

#include "stdafx.h"
#include "Spec.h"

#include "MassSpecDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSpecApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc

IMPLEMENT_DYNCREATE(CMassSpecDoc, CDocument)

BEGIN_MESSAGE_MAP(CMassSpecDoc, CDocument)
	//{{AFX_MSG_MAP(CMassSpecDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc construction/destruction

CMassSpecDoc::CMassSpecDoc()
{
}

CMassSpecDoc::~CMassSpecDoc()
{
	SaveDefMassTable();
}

BOOL CMassSpecDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	InitDoc();
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc serialization

void CMassSpecDoc::Serialize(CArchive& ar)
{
	char Key[4]="msp";
	char DocVersion=1;
	if (ar.IsStoring())
	{
		ar.Write(&Key,3);
		ar << DocVersion;
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc diagnostics

#ifdef _DEBUG
void CMassSpecDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMassSpecDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc commands

void CMassSpecDoc::InitDoc()
{
	char EntryName[50];
	char EntryContents[256];
	CMassTable Row;
	int i, Checked;

	for(i=0; i<MAX_MASS_COUNT;i++)
	{
		sprintf(EntryName, "Entry_%.2i", i);
		GetPrivateProfileString("Mass Table", EntryName, "1, 55,ABC D e 123", EntryContents, 256, theApp.m_psIniFileName);
		//if(strcmp(EntryContents,"0, 0,")==0)
			//break;
		memset(Row.Comments,0,sizeof(Row.Comments));
		sscanf(EntryContents, "%i,%i,%63c", &Checked, &Row.Mass, Row.Comments);
		Row.Checked=Checked;
		m_MassTable.push_back(Row);
	}
	
}

void CMassSpecDoc::SaveDefMassTable()
{
	char EntryName[50];
	char EntryContents[256];
	for(int i=0; i<m_MassTable.size();i++)
	{
		sprintf(EntryName, "Entry_%.2i", i);
		CMassTable *pRow=&m_MassTable[i];
		sprintf(EntryContents, "%i,%i,%s", (int)pRow->Checked, pRow->Mass, pRow->Comments);
		WritePrivateProfileString("Mass Table", EntryName, EntryContents, theApp.m_psIniFileName);
	}
}
