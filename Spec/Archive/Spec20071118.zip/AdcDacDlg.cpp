// AdcDacDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Spec.h"
#include "AdcDacDlg.h"
#include "Functions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdcDacDlg dialog


CAdcDacDlg::CAdcDacDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdcDacDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdcDacDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAdcDacDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdcDacDlg)
	DDX_Control(pDX, IDC_STATIC_ADC0, m_StaticAdc0);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdcDacDlg, CDialog)
	//{{AFX_MSG_MAP(CAdcDacDlg)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_COM_EVENT, OnSerialLinkEvent)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdcDacDlg message handlers

BOOL CAdcDacDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	theApp.m_SerialLink.m_Pool.RegisterMsgReception(GetSafeHwnd());
	SetTimer(TIMER_POLL_SERIAL,500,NULL);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAdcDacDlg::OnDestroy() 
{
	theApp.m_SerialLink.m_Pool.UnRegisterMsgReception(GetSafeHwnd());
	CDialog::OnDestroy();
}

LRESULT CAdcDacDlg::OnSerialLinkEvent(WPARAM WParam, LPARAM LParam)
{
	int MsgType=HIWORD(LParam);
	BYTE Cmd=(BYTE)LOWORD(LParam);
	int Adc0;
	if(Cmd==CMD_GET_EXT_ADC && MsgType==SERIAL_SYNC_MSG)
	{
		ComMsg msg=theApp.m_SerialLink.m_Pool.GetMsg(WParam);
		Adc0=BytesToShort(msg.Buf[1],msg.Buf[2]);
		char ch[30];
		sprintf(ch,"%d",Adc0);
		m_StaticAdc0.SetWindowText(ch);			
	}
	else if(MsgType==SERIAL_ERROR_COM_FAILED || MsgType==SERIAL_ERROR_TIMEOUT)
	{
		m_StaticAdc0.SetWindowText("...");			

	}
	return (LRESULT)0;
}

void CAdcDacDlg::OnTimer(UINT nIDEvent) 
{
	switch(nIDEvent)
	{
		case TIMER_POLL_SERIAL:
		{
			ComMsg msg;
			msg.Buf[0]=CMD_GET_EXT_ADC;
			msg.Buf[1]=0;
			msg.MsgSize=2;
			msg.WaitForReply=true;
			theApp.m_SerialLink.SendComMessage(msg);
			break;
		}
	}	
	CDialog::OnTimer(nIDEvent);
}
