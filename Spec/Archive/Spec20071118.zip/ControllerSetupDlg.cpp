// ControllerSetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Spec.h"
#include "ControllerSetupDlg.h"
#include "Functions.h"
#include "AdcDacDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CControllerSetupDlg dialog


CControllerSetupDlg::CControllerSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CControllerSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CControllerSetupDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CControllerSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControllerSetupDlg)
	DDX_Control(pDX, IDC_EDIT_DERIV_SAMPLES, m_EditDerivSamples);
	DDX_Control(pDX, IDC_STATIC_VP_F, m_StaticVpF);
	DDX_Control(pDX, IDC_STATIC_VI_F, m_StaticViF);
	DDX_Control(pDX, IDC_STATIC_VD_F, m_StaticVdF);
	DDX_Control(pDX, IDC_STATIC_PID_OUT, m_StaticPidOut);
	DDX_Control(pDX, IDC_STATIC_FEEDFORW_VF, m_StaticFeedForwVF);
	DDX_Control(pDX, IDC_STATIC_FEEDFORW_V, m_StaticFeedForwV);
	DDX_Control(pDX, IDC_EDIT_ZERO_VI, m_EditZeroVi);
	DDX_Control(pDX, IDC_EDIT_VI_MAX, m_EditViMax);
	DDX_Control(pDX, IDC_EDIT_KFF, m_EditKff);
	DDX_Control(pDX, IDC_EDIT_KP, m_EditKp);
	DDX_Control(pDX, IDC_EDIT_KI, m_EditKi);
	DDX_Control(pDX, IDC_EDIT_KD, m_EditKd);
	DDX_Control(pDX, IDC_EDIT_COM_PORT_NAME, m_EditComPortName);
	DDX_Control(pDX, IDC_STATIC_OUTPUT, m_StaticOutput);
	DDX_Control(pDX, IDC_STATIC_VP, m_StaticVP);
	DDX_Control(pDX, IDC_STATIC_VI, m_StaticVI);
	DDX_Control(pDX, IDC_STATIC_VD, m_StaticVD);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CControllerSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CControllerSetupDlg)
	ON_BN_CLICKED(IDC_BUTTON_PID_COEF_LOAD, OnButtonPidCoefLoad)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_BUTTON_COM_RECONNECT, OnButtonComReconnect)
	ON_EN_KILLFOCUS(IDC_EDIT_KD, OnKillfocusEditKd)
	ON_EN_KILLFOCUS(IDC_EDIT_KI, OnKillfocusEditKi)
	ON_EN_KILLFOCUS(IDC_EDIT_KP, OnKillfocusEditKp)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_ADC_DAC, OnButtonAdcDac)
	ON_BN_CLICKED(IDC_BUTTON_PID_PARAM_LOAD2, OnButtonPidParamLoad)
	ON_EN_KILLFOCUS(IDC_EDIT_KFF, OnKillfocusEditKff)
	ON_EN_KILLFOCUS(IDC_EDIT_DERIV_SAMPLES, OnKillfocusEditDerivSamples)
	ON_EN_KILLFOCUS(IDC_EDIT_VI_MAX, OnKillfocusEditViMax)
	ON_EN_KILLFOCUS(IDC_EDIT_ZERO_VI, OnKillfocusEditZeroVi)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_COM_EVENT, OnComEvent)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControllerSetupDlg message handlers

void CControllerSetupDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	if(bShow)
	{
	}	
}

void CControllerSetupDlg::OnButtonComReconnect() 
{
	char ch[20];
	m_EditComPortName.GetWindowText(ch,sizeof(ch));
	theApp.Ini.ComPortName=ch;
	theApp.m_SerialLink.ReconnectCom(ch);	
}

BOOL CControllerSetupDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	theApp.m_SerialLink.m_Pool.RegisterMsgReception(GetSafeHwnd());
	SetTimer(TIMER_POLL_PID_VALS,500,NULL);
	char ch[30];
	
	m_EditComPortName.SetWindowText((LPCSTR)theApp.Ini.ComPortName);
	sprintf(ch,"%.3f",CorrectInt16Q8(theApp.Ini.PidKp));
	m_EditKp.SetWindowText(ch);
	sprintf(ch,"%.3f",CorrectInt16Q8(theApp.Ini.PidKi));
	m_EditKi.SetWindowText(ch);
	sprintf(ch,"%.3f",CorrectInt16Q8(theApp.Ini.PidKd));
	m_EditKd.SetWindowText(ch);
	sprintf(ch,"%.3f",CorrectInt16Q8(theApp.Ini.TRegKff));
	m_EditKff.SetWindowText(ch);
	sprintf(ch,"%i",MinMax(0,15,theApp.Ini.PidDerivativeBy));
	m_EditDerivSamples.SetWindowText(ch);
	sprintf(ch,"%.2f",CorrectInt16Q4(theApp.Ini.PidViMinMax));
	m_EditViMax.SetWindowText(ch);
	sprintf(ch,"%.2f",CorrectInt16Q4(theApp.Ini.PidZeroVi));
	m_EditZeroVi.SetWindowText(ch);

	m_StaticVP.SetWindowText("...");
	m_StaticVpF.SetWindowText("...");			
	m_StaticVI.SetWindowText("...");
	m_StaticViF.SetWindowText("...");
	m_StaticVD.SetWindowText("...");
	m_StaticVdF.SetWindowText("...");
	m_StaticPidOut.SetWindowText("...");
	m_StaticFeedForwV.SetWindowText("...");
	m_StaticFeedForwVF.SetWindowText("...");
	m_StaticOutput.SetWindowText("...");


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CControllerSetupDlg::OnKillfocusEditKd() 
{
	char ch[30];
	m_EditKd.GetWindowText(ch,sizeof(ch));
	sprintf(ch,"%.3f",CorrectInt16Q8(atof(ch)));
	m_EditKd.SetWindowText(ch);
}

void CControllerSetupDlg::OnKillfocusEditKi() 
{
	char ch[30];
	m_EditKi.GetWindowText(ch,sizeof(ch));
	sprintf(ch,"%.3f",CorrectInt16Q8(atof(ch)));
	m_EditKi.SetWindowText(ch);
}

void CControllerSetupDlg::OnKillfocusEditKp() 
{
	char ch[30];
	m_EditKp.GetWindowText(ch,sizeof(ch));
	sprintf(ch,"%.3f",CorrectInt16Q8(atof(ch)));
	m_EditKp.SetWindowText(ch);
}

void CControllerSetupDlg::OnKillfocusEditKff() 
{
	char ch[30];
	m_EditKff.GetWindowText(ch,sizeof(ch));
	sprintf(ch,"%.3f",CorrectInt16Q8(atof(ch)));
	m_EditKff.SetWindowText(ch);	
}

void CControllerSetupDlg::OnKillfocusEditDerivSamples() 
{
	char ch[30];
	m_EditDerivSamples.GetWindowText(ch,sizeof(ch));
	sprintf(ch,"%i",MinMax(atoi(ch),1,15));
	m_EditDerivSamples.SetWindowText(ch);	
}

void CControllerSetupDlg::OnKillfocusEditViMax() 
{
	char ch[30];
	m_EditViMax.GetWindowText(ch,sizeof(ch));
	sprintf(ch,"%.2f",CorrectInt16Q4(atof(ch)));
	m_EditViMax.SetWindowText(ch);	
}

void CControllerSetupDlg::OnKillfocusEditZeroVi() 
{
	char ch[30];
	m_EditZeroVi.GetWindowText(ch,sizeof(ch));
	sprintf(ch,"%.2f",CorrectInt16Q4(atof(ch)));
	m_EditZeroVi.SetWindowText(ch);	
}

void CControllerSetupDlg::OnOK() 
{
	SavePidCoefs();
	SavePidParam();
	char ch[30];
	m_EditComPortName.GetWindowText(ch,sizeof(ch));
	theApp.Ini.ComPortName=ch;

	CDialog::OnOK();
}

void CControllerSetupDlg::SavePidCoefs()
{
	char ch[30];
	m_EditKd.GetWindowText(ch,sizeof(ch));
	theApp.Ini.PidKd=CorrectInt16Q8(atof(ch));
	m_EditKi.GetWindowText(ch,sizeof(ch));
	theApp.Ini.PidKi=CorrectInt16Q8(atof(ch));
	m_EditKp.GetWindowText(ch,sizeof(ch));
	theApp.Ini.PidKp=CorrectInt16Q8(atof(ch));
	m_EditKff.GetWindowText(ch,sizeof(ch));
	theApp.Ini.TRegKff=CorrectInt16Q8(atof(ch));
}

void CControllerSetupDlg::OnButtonPidCoefLoad()
{
	SavePidCoefs();
	ComMsg msg;
	msg.Buf[0]=CMD_LOAD_PIDCOEFS;
	msg.Buf[1]=Int16Q8Low(theApp.Ini.PidKp);
	msg.Buf[2]=Int16Q8High(theApp.Ini.PidKp);
	msg.Buf[3]=Int16Q8Low(theApp.Ini.PidKi);
	msg.Buf[4]=Int16Q8High(theApp.Ini.PidKi);
	msg.Buf[5]=Int16Q8Low(theApp.Ini.PidKd);
	msg.Buf[6]=Int16Q8High(theApp.Ini.PidKd);
	msg.MsgSize=7;
	msg.WaitForReply=true;
	theApp.m_SerialLink.SendComMessage(msg);	
}

LRESULT CControllerSetupDlg::OnComEvent(WPARAM WParam, LPARAM LParam)
{
	int MsgType=HIWORD(LParam);
	BYTE Cmd=(BYTE)LOWORD(LParam);
	double Vp,Vi,Vd,VPidOut, Vff, VpF, ViF, VdF, VffF, Vout;
	if(Cmd==CMD_GET_PIDVALS && MsgType==SERIAL_SYNC_MSG)
	{
		ComMsg msg=theApp.m_SerialLink.m_Pool.GetMsg(WParam);
		Vp=BytesToShort(msg.Buf[1],msg.Buf[2])/16.;
		Vi=BytesToShort(msg.Buf[3],msg.Buf[4])/16.;
		Vd=BytesToShort(msg.Buf[5],msg.Buf[6])/16.;
		VPidOut=BytesToShort(msg.Buf[7],msg.Buf[8])/16.;
		Vff=BytesToShort(msg.Buf[9],msg.Buf[10])/16.;
		Vout=BytesToShort(msg.Buf[11],msg.Buf[12])/16.;
		VpF=Vp*theApp.Ini.PidKp;
		ViF=Vi*theApp.Ini.PidKi;
		VdF=Vd*theApp.Ini.PidKd;
		VffF=VffF=Vff*theApp.Ini.TRegKff;
		char ch[30];
		sprintf(ch,"%.2f",Vp);
		m_StaticVP.SetWindowText(ch);
		sprintf(ch,"%.2f",VpF);
		m_StaticVpF.SetWindowText(ch);
		sprintf(ch,"%.2f",Vi);
		m_StaticVI.SetWindowText(ch);
		sprintf(ch,"%.2f",ViF);
		m_StaticViF.SetWindowText(ch);
		sprintf(ch,"%.2f",Vd);
		m_StaticVD.SetWindowText(ch);
		sprintf(ch,"%.2f",VdF);
		m_StaticVdF.SetWindowText(ch);
		sprintf(ch,"%.2f",VPidOut);
		m_StaticPidOut.SetWindowText(ch);
		sprintf(ch,"%.2f",Vff);
		m_StaticFeedForwV.SetWindowText(ch);
		sprintf(ch,"%.2f",VffF);
		m_StaticFeedForwVF.SetWindowText(ch);
		sprintf(ch,"%.2f",Vout);
		m_StaticOutput.SetWindowText(ch);

	}
	else if(MsgType==SERIAL_ERROR_COM_FAILED || MsgType==SERIAL_ERROR_TIMEOUT)
	{
		m_StaticVP.SetWindowText("...");
		m_StaticVpF.SetWindowText("...");			
		m_StaticVI.SetWindowText("...");
		m_StaticViF.SetWindowText("...");
		m_StaticVD.SetWindowText("...");
		m_StaticVdF.SetWindowText("...");
		m_StaticPidOut.SetWindowText("...");
		m_StaticFeedForwV.SetWindowText("...");
		m_StaticFeedForwVF.SetWindowText("...");
		m_StaticOutput.SetWindowText("...");
	}

	return (LRESULT)0;
}


void CControllerSetupDlg::OnDestroy() 
{
	theApp.m_SerialLink.m_Pool.UnRegisterMsgReception(GetSafeHwnd());
	CDialog::OnDestroy();
}

void CControllerSetupDlg::OnTimer(UINT nIDEvent) 
{
	switch(nIDEvent)
	{
		case TIMER_POLL_PID_VALS:
		{
			ComMsg msg;
			msg.Buf[0]=CMD_GET_PIDVALS;
			msg.MsgSize=1;
			msg.WaitForReply=true;
			theApp.m_SerialLink.SendComMessage(msg);
			break;
		}
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CControllerSetupDlg::OnButtonAdcDac() 
{
	CAdcDacDlg dlg;
	dlg.DoModal();	
}

void CControllerSetupDlg::SavePidParam()
{
	char ch[30];
	m_EditDerivSamples.GetWindowText(ch,sizeof(ch));
	theApp.Ini.PidDerivativeBy=atoi(ch);	
	m_EditViMax.GetWindowText(ch,sizeof(ch));
	theApp.Ini.PidViMinMax=atof(ch);
	m_EditZeroVi.GetWindowText(ch,sizeof(ch));
	theApp.Ini.PidZeroVi=atof(ch);
}

void CControllerSetupDlg::OnButtonPidParamLoad() 
{
	SavePidParam();
	
}

