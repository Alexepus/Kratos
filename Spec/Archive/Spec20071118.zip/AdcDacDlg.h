#if !defined(AFX_ADCDACDLG_H__059873AE_72C7_48C0_8D02_616A8B8107C7__INCLUDED_)
#define AFX_ADCDACDLG_H__059873AE_72C7_48C0_8D02_616A8B8107C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AdcDacDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAdcDacDlg dialog
#define TIMER_POLL_SERIAL 1

class CAdcDacDlg : public CDialog
{
// Construction
public:
	CAdcDacDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAdcDacDlg)
	enum { IDD = IDD_ADCDAC_DLG };
	CStatic	m_StaticAdc0;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdcDacDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAdcDacDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	LRESULT OnSerialLinkEvent(WPARAM WParam, LPARAM LParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADCDACDLG_H__059873AE_72C7_48C0_8D02_616A8B8107C7__INCLUDED_)
