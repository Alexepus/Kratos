// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Spec.h"
#include "SpecView.h"
#include "HSChart\\ChartCtrl.h"
#include "MainFrame.h"
#include "MeasuringOptDlg.h"
#include "HardSetupDlg.h"
#include "resource.h"
#include "Threads.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_SETTINGS_HARDWARE, OnSettingsHardware)
	ON_COMMAND(ID_SETTINGS_MEASURINGOPTIONS, OnSettingsMeasuringOptions)
	ON_WM_CLOSE()
	ON_COMMAND(ID_TR_TRSETTINGS, OnTrTrsettings)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_REMAIN_TIME, OnUpdateStatusRemainTime)
	//ON_UPDATE_COMMAND_UI(ID_INDICATOR_REF_TEMP, OnUpdateStatusRefTemp)
	//ON_UPDATE_COMMAND_UI(ID_INDICATOR_CUR_TEMP, OnUpdateStatusCurTemp)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
//	ID_INDICATOR_CAPS,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_SCRL,
	ID_INDICATOR_REF_TEMP,
	ID_INDICATOR_CUR_TEMP,
	ID_INDICATOR_REMAIN_TIME
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame():m_dRemainTime(0)
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC|CBRS_FLOATING) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	CPoint point(50,50);
	if (!m_wndToolBarTR.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC|CBRS_FLOATING) ||
		!m_wndToolBarTR.LoadToolBar(IDR_TOOLBAR_TR))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	//FloatControlBar(&m_wndToolBar, point, CBRS_ALIGN_RIGHT  );
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBarTR.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	ClientToScreen(&theApp.Ini.MainToolBarRect);
	DockControlBar(&m_wndToolBar,AFX_IDW_DOCKBAR_TOP|AFX_IDW_DOCKBAR_LEFT,&theApp.Ini.MainToolBarRect);
	ClientToScreen(&theApp.Ini.TRToolBarRect);
	DockControlBar(&m_wndToolBarTR,AFX_IDW_DOCKBAR_TOP|AFX_IDW_DOCKBAR_LEFT,&theApp.Ini.TRToolBarRect);
	//FloatControlBar(&m_wndToolBarTR,point);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style=cs.style&~FWS_ADDTOTITLE;
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
return	CFrameWnd::OnCreateClient(lpcs, pContext); 
}

void CMainFrame::OnSettingsHardware() 
{
	CHardSetupDlg dlg;
	dlg.DoModal();
}


void CMainFrame::OnSettingsMeasuringOptions() 
{
	CMeasuringOptDlg dlg;
	if(dlg.DoModal()==IDOK)
	{
		CView* pView=GetActiveView();
		if(pView->IsKindOf(RUNTIME_CLASS(CSpecView)))
		{
			CSpecView *pSpecView=(CSpecView*)pView;
			if(pSpecView->m_bCalibration)
			{
				pSpecView->m_pChart->GetBottomAxis()->SetMinMax(theApp.Ini.CalibMassStart,theApp.Ini.CalibMassStop);
				pSpecView->m_pChart->RefreshCtrl();
			}
		}
	}
}

void CMainFrame::OnClose() 
{
	m_wndToolBar.GetWindowRect(&theApp.Ini.MainToolBarRect);
	ScreenToClient(&theApp.Ini.MainToolBarRect);
	m_wndToolBarTR.GetWindowRect(&theApp.Ini.TRToolBarRect);
	ScreenToClient(&theApp.Ini.TRToolBarRect);
	DWORD ExitCode;
	SetEvent(theApp.m_EventThreadExit);
	if(theApp.m_pThread)
	{
		GetExitCodeThread(theApp.m_pThread->m_hThread,&ExitCode);
		if(ExitCode==STILL_ACTIVE)
			TerminateThread(theApp.m_pThread->m_hThread,1);
	}
	if(WaitForSingleObject(theApp.m_hThermoRegThread,2000)==WAIT_TIMEOUT)
			MessageBox("����� ��������������� �� ��������������. ��� ��������������\n"
			"���������� ��������, ��� ����������� ��������� ���������.","Spec - ������", 
				MB_ICONERROR|MB_OK);

	CFrameWnd::OnClose();
}

void CMainFrame::OnUpdateStatusRefTemp(CCmdUI *pCmdUI)
{

}

void CMainFrame::OnUpdateStatusCurTemp(CCmdUI *pCmdUI)
{

}

void CMainFrame::OnUpdateStatusRemainTime(CCmdUI *pCmdUI)
{
    pCmdUI->Enable(); 
    CString strTime;
	int Hours=abs(m_dRemainTime/3600);
	int Minutes=abs((int)(m_dRemainTime/60))%60;
	int Seconds=abs((int)m_dRemainTime)%60;
	double Milliseconds=fabs(m_dRemainTime)-floor(fabs(m_dRemainTime));
	char Sign[2];
	strcpy(Sign,(m_dRemainTime>=0)?" ":"-");
    strTime.Format( "%s%.2i:%.2i:%.2i", Sign,Hours,Minutes,Seconds);  
    pCmdUI->SetText(strTime);
}

void CMainFrame::SetStatusRemainTime(double Time)
{
	m_dRemainTime=Time;
    CString strTime;
	int Hours=abs(m_dRemainTime/3600);
	int Minutes=abs((int)(m_dRemainTime/60))%60;
	int Seconds=abs((int)m_dRemainTime)%60;
	double Milliseconds=fabs(m_dRemainTime)-floor(fabs(m_dRemainTime));
	char Sign[2];
	strcpy(Sign,(m_dRemainTime>=0)?" ":"-");
    strTime.Format( "%s%.2i:%.2i:%.2i", Sign,Hours,Minutes,Seconds);
	::SendMessage(m_wndStatusBar.GetSafeHwnd(), SB_SETTEXT,	3, (LPARAM) (LPCSTR) strTime);
}

void CMainFrame::OnTrTrsettings() 
{
	CThermoSettingsDlg dlg;
	dlg.DoModal();
}


