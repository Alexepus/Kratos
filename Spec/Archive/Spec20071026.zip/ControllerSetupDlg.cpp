// ControllerSetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Spec.h"
#include "ControllerSetupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CControllerSetupDlg dialog


CControllerSetupDlg::CControllerSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CControllerSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CControllerSetupDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CControllerSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControllerSetupDlg)
	DDX_Control(pDX, IDC_STATIC_OUTPUT, m_StaticOutput);
	DDX_Control(pDX, IDC_STATIC_VP, m_StaticVP);
	DDX_Control(pDX, IDC_STATIC_VI, m_StaticVI);
	DDX_Control(pDX, IDC_STATIC_VD, m_StaticVD);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CControllerSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CControllerSetupDlg)
	ON_BN_CLICKED(IDC_BUTTON_PID_COEF_LOAD, OnButtonPidCoefLoad)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControllerSetupDlg message handlers

void CControllerSetupDlg::OnButtonPidCoefLoad() 
{
	// TODO: Add your control notification handler code here
	
}

void CControllerSetupDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	if(bShow)
	{
		m_StaticVP.SetWindowText("...");			
		m_StaticVI.SetWindowText("...");
		m_StaticVD.SetWindowText("...");
		m_StaticOutput.SetWindowText("...");
	}	
}
