#ifndef _HEATER_H_
#define _HEATER_H_

#include "ThreadSafeQueue.h"

enum eCmd{CmdStart,CmdPrime,CmdGo,CmdWait,CmdContinue,CmdMainOff};


class CHeaterCommands
{
public:
	CHeaterCommands(){CommandMainOff();}
	~CHeaterCommands(){CommandMainOff();}

	eCmd State;
	bool WaitState;
	CThreadSafeQueue<DWORD> Queue;

	void CommandStart()
	{
		State=CmdStart;
		WaitState=false;
	}

	void CommandPrime()
	{
		State=CmdPrime;
		WaitState=false;
	}

	void CommandGo()
	{
		State=CmdGo;
		WaitState=false;
	}

	void CommandWait()
	{
		if(State!=CmdMainOff)
			WaitState=true;
	}

	void CommandContinue()
	{
		WaitState=false;
	}

	void CommandWaitContinue()
	{
		if(State!=CmdMainOff)
			WaitState=!WaitState;
		else
			WaitState=false;
	}

	void CommandMainOff()
	{
		State=CmdMainOff;
		WaitState=false;
	}

};

#endif