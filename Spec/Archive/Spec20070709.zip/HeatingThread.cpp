#include "stdafx.h"
#include "LogToFile.h"
#include "HSChart/ChartCtrl.h"
#include "MainFrame.h"
#include "Threads.h"
#include "math.h"

DWORD WINAPI HeatingThread(LPVOID pParam)
{
	//CSpecView *pSpecView=(CSpecView *)pParam;
	CMainFrame *pMainFrame=(CMainFrame*)theApp.m_pMainWnd;
	CThreadSafeQueue<DWORD> * pQueue=&pMainFrame->HeaterCommands.Queue;
	HANDLE Events[2]={theApp.m_EventThreadExit, pQueue->m_EventHasData};
	DWORD WaitResult;
	DWORD TimeOut=500;
	while((WaitResult=WaitForMultipleObjects(2, Events, FALSE, TimeOut))!=WAIT_OBJECT_0)
	{
		if(WaitResult==WAIT_OBJECT_0+1)
		{
			
		}
	}
	return 0;
}