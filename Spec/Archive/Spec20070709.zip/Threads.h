#ifndef _THREADS_H_
#define _THREADS_H_

#define SIMULATION

UINT CalibThread(LPVOID pParam);
UINT MeasuringThread(LPVOID pParam);
DWORD WINAPI HeatingThread(LPVOID pParam);

#endif
