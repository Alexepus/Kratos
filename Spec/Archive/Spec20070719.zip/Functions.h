#ifndef _FUNCTIONS_H_INCLUDED_
#define _FUNCTIONS_H_INCLUDED_

#define TF_OK 0
#define TF_INVALID_BETAS 1
#define TF_INVALID_TOTAL_PERIOD 2
#define TF_INVALID_COOLING_HEATING_RATE 3
#define TF_ERROR_T1_LW_T2 4

int VerifyThermoFunction(CThermoFunc *pTF);
void ReportThermoFunctionError(int ErrCode, CWnd *pWnd);
double GetTimeDouble();
double Mod(double Divident, double Divisor);

#endif