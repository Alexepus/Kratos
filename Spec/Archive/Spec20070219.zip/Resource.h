//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Spec.rc
//
#define IDD_ABOUTBOX                    100
#define ID_INDICATOR_REF_TEMP           101
#define ID_INDICATOR_CUR_TEMP           102
#define ID_INDICATOR_REMAIN_TIME        103
#define IDR_MAINFRAME                   128
#define IDR_MSPTYPE                     129
#define ID_CHART                        130
#define IDC_CURSOR_DIVSIZE              130
#define ID_LIST                         131
#define IDD_CALIB_DLG                   131
#define IDC_CURSOR_GRAPH                133
#define IDD_MEASURING_OPT_DLG           136
#define IDD_HARDWARE_SETUP_DLG          137
#define IDD_APPEARANCE_SETUP_DLG        139
#define IDC_BUTTON_CALIB_OK             1000
#define IDC_LIST_CALIB                  1002
#define IDC_STATIC_BUILD_DATE           1003
#define IDC_BUTTON_CALIB_CANCEL         1004
#define IDC_EDIT_MASS_START             1005
#define IDC_EDIT_MASS_STOP              1006
#define IDC_EDIT_MASS_STEP              1007
#define IDC_EDIT_MASS_SETUP_DELAY       1008
#define IDC_COMBO_INTEGRATION           1009
#define IDC_COMBO_RANGE                 1010
#define IDC_APPEARANCE_CALIB_CHART      1011
#define IDC_COMBO_SERIES1_TYPE          1012
#define IDC_COMBO_SERIES1_ELEMENT       1013
#define IDC_BUTTON_SERIES1_COLOR        1014
#define IDC_SLIDER_SERIES1_SIZE         1015
#define IDC_STATIC_SIZE                 1016
#define IDC_COMBO_SERIES2_TYPE          1017
#define IDC_COMBO_SERIES2_ELEMENT       1018
#define IDC_BUTTON_SERIES2_COLOR        1019
#define IDC_SLIDER_SERIES2_SIZE         1020
#define IDC_STATIC_SIZE2                1021
#define IDC_DATETIMEPICKER              1024
#define ID_SETTINGS_HARDWARE            32771
#define ID_VIEW_MASSES                  32772
#define ID_SETTINGS_CALIBRATION         32774
#define ID_BUTTON_START                 32777
#define ID_BUTTON_STOP                  32778
#define ID_SETTINGS_MEASURINGOPTIONS    32780
#define ID_SETTINGS_APPEARANCE          32781
#define IDM_FILE_SAVEAS_EASYPLOT        32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
