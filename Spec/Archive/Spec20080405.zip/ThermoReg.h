// ThermoReg.h: interface for the CThermoReg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_THERMOREG_H__12D22E4B_6B64_4653_BA2C_B12A1984D984__INCLUDED_)
#define AFX_THERMOREG_H__12D22E4B_6B64_4653_BA2C_B12A1984D984__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ThermoHistDoc.h"
#include "HeaterCommands.h"

#define TIMER_THERMOREG_1SEC 5
#define TIMER_THERMOREG_THERMOFUNC 6
using namespace std;

class CThermoReg  
{
private:
	CSpecView* m_pSpecView;
	vector<double> m_ThermoPair_mV; //������� � ��
	double m_ThermoPairStartT, m_ThermoPairDeltaT;

	//��������� �����
	bool m_StatusThermoPairLoad;
	bool m_StatusComPort;
	bool m_StatusController;

	ComMsg msg;

	//��� �����
	int TestTC_i;
	FILE* TestTC_pFile;

public:
	static void LoadDacValue(int Channel, int Value);
	static void SendManualHeaterMode(bool Manual);
	static void UploadFfTable();
	static void UploadPidParams();
	static void UploadPidCoefs();
	void UpLoadThermoPairToController();
	void OnTimer(UINT nIDEvent);
	void TestTC(int i);
	bool IsEverythingOK(){return m_StatusThermoPairLoad && m_StatusComPort&&m_StatusController; };
	void Init(CSpecView* pSpecView);
	bool LoadThermoPairFile(CString FilePath);
	double GetTByThermoPairmV(double mV);
	double GetThermoPairmVByT(double T);
	LRESULT OnSerialEvent(WPARAM WParam, LPARAM LParam);
	CThermoHistDoc m_Hist;
	CHeaterCommands m_Commands;

	CThermoReg();
	virtual ~CThermoReg();

};

#endif // !defined(AFX_THERMOREG_H__12D22E4B_6B64_4653_BA2C_B12A1984D984__INCLUDED_)
