// AppearSetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Spec.h"
#include "AppearSetupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAppearSetupDlg dialog


CAppearSetupDlg::CAppearSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAppearSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAppearSetupDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAppearSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAppearSetupDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAppearSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CAppearSetupDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAppearSetupDlg message handlers

BOOL CAppearSetupDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAppearSetupDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}
