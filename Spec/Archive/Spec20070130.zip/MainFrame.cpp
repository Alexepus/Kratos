// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Spec.h"
#include "SpecView.h"
#include "HSChart\\ChartCtrl.h"
#include "MainFrame.h"
#include "MeasuringOptDlg.h"
#include "HardSetupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_SETTINGS_HARDWARE, OnSettingsHardware)
	ON_COMMAND(ID_SETTINGS_MEASURINGOPTIONS, OnSettingsMeasuringOptions)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC|CBRS_FLOATING) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	CPoint point(50,50);
	//FloatControlBar(&m_wndToolBar, point, CBRS_ALIGN_RIGHT  );
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
return	CFrameWnd::OnCreateClient(lpcs, pContext); 
}

void CMainFrame::OnSettingsHardware() 
{
	CHardSetupDlg dlg;
	dlg.DoModal();
}


void CMainFrame::OnSettingsMeasuringOptions() 
{
	CMeasuringOptDlg dlg;
	if(dlg.DoModal()==IDOK)
	{
		CView* pView=GetActiveView();
		if(pView->IsKindOf(RUNTIME_CLASS(CSpecView)))
		{
			CSpecView *pSpecView=(CSpecView*)pView;
			if(pSpecView->m_bCalibration)
			{
				pSpecView->m_pChart->GetBottomAxis()->SetMinMax(theApp.m_Options.CalibMassStart.dVal,theApp.m_Options.CalibMassStop.dVal);
				pSpecView->m_pChart->RefreshCtrl();
			}
		}
	}
}

void CMainFrame::OnClose() 
{
	DWORD ExitCode;
	if(theApp.m_pThread)
	{
		GetExitCodeThread(theApp.m_pThread->m_hThread,&ExitCode);
		if(ExitCode==STILL_ACTIVE);
			TerminateThread(theApp.m_pThread->m_hThread,1);
	}
	
	CFrameWnd::OnClose();
}
