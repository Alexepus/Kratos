#ifndef _THREADS_H_
#define _THREADS_H_

#define SIMULATION

#define WM_UPDATE_THERMO_DATA	(WM_APP + 10003)

UINT CalibThread(LPVOID pParam);
UINT MeasuringThread(LPVOID pParam);
DWORD WINAPI HeatingThread(LPVOID pParam);
double EmulateMeasTemp(double RefTemp, bool On);

double CalcRefTemp(CThermoFunc *pThermoFunc, double TimeFromStart, double &CurrentSlope, double &TimeToInflection, double &TEnd);
#endif
