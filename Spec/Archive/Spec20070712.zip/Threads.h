#ifndef _THREADS_H_
#define _THREADS_H_

#define SIMULATION

#define WM_UPDATE_THERMO_DATA	(WM_APP + 10003)

UINT CalibThread(LPVOID pParam);
UINT MeasuringThread(LPVOID pParam);
DWORD WINAPI HeatingThread(LPVOID pParam);
double GetTimeDouble();
double Mod(double Divident, double Divisor);

double CalcRefTemp(CThermoFunc *pThermoFunc, double TimeFromStart, double &CurrentSlope, double &TimeToInflection);
#endif
