// CalibDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Spec.h"
#include "CalibDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#include "SpecView.h"
/////////////////////////////////////////////////////////////////////////////
// CCalibDlg dialog


CCalibDlg::CCalibDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCalibDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCalibDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CCalibDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCalibDlg)
	DDX_Control(pDX, IDC_BUTTON_CALIB_OK, m_ButtonOK);
	DDX_Control(pDX, IDC_LIST_CALIB, m_List);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCalibDlg, CDialog)
	//{{AFX_MSG_MAP(CCalibDlg)
	ON_BN_CLICKED(IDC_BUTTON_CALIB_OK, OnButtonCalibOk)
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalibDlg message handlers

void CCalibDlg::OnButtonCalibOk() 
{
	ShowWindow(SW_HIDE);
	m_pSpecView->OnButtonCalibOK();
}

void CCalibDlg::OnSize(UINT nType, int cx, int cy) 
{
	//CDialog::OnSize(nType, cx, cy);
	//CRect OriginDlgRect(1, 1, 97, 239);
	//CRect OriginListRect(1, 1, 97, 259);
	CRect OriginSubListRect(1, 239, 97, 259);
	CRect OriginButtonRect(23, 242, 23+50, 242+14);

	MapDialogRect(&OriginSubListRect);
	MapDialogRect(&OriginButtonRect);

	m_ListRect.left=0; m_ListRect.top=0; m_ListRect.right=cx;
	m_ListRect.bottom=cy-OriginSubListRect.Height();
	if(::IsWindow(m_List.GetSafeHwnd()))
		m_List.MoveWindow(m_ListRect);

	m_ButtonOKRect.left=cx/2-OriginButtonRect.Width()/2;
	m_ButtonOKRect.top=cy-OriginSubListRect.Height()/2-OriginButtonRect.Height()/2;
	
	if(::IsWindow(m_ButtonOK.GetSafeHwnd()))
		m_ButtonOK.SetWindowPos(NULL, m_ButtonOKRect.left, m_ButtonOKRect.top, 0, 0, SWP_NOSIZE|SWP_NOZORDER);

	//UpdateWindow();
	
}


BOOL CCalibDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_List.SetExtendedStyle(LVS_EX_GRIDLINES);
	m_List.SetCheckboxeStyle();
	m_List.InsertColumn(0,"Col1");
	m_List.InsertItem(0,"111");
	m_List.InsertItem(1,"222");
	m_List.ModifyStyle(0,WS_BORDER);
	m_List.ModifyStyleEx(WS_EX_STATICEDGE|WS_EX_CLIENTEDGE,0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CCalibDlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	//if(m_bCalibration)
		//DrawDlgArea(m_CalibDlgRect, pDC);
	pDC->ExcludeClipRect(m_ListRect);
	return CDialog::OnEraseBkgnd(pDC);
}


