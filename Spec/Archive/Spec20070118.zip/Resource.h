//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Spec.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MSPTYPE                     129
#define ID_CHART                        130
#define IDC_CURSOR_DIVSIZE              130
#define ID_LIST                         131
#define IDD_CALIB_DLG                   131
#define IDC_CURSOR_GRAPH                133
#define IDC_BUTTON_CALIB_OK             1000
#define IDC_LIST_CALIB                  1002
#define ID_SETTINGS_HARDWARE            32771
#define ID_VIEW_MASSES                  32772
#define ID_SETTINGS_CALIBRATION         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
