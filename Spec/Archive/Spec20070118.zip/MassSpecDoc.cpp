// MassSpecDoc.cpp : implementation of the CMassSpecDoc class
//

#include "stdafx.h"
#include "Spec.h"

#include "MassSpecDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CSpecApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc

IMPLEMENT_DYNCREATE(CMassSpecDoc, CDocument)

BEGIN_MESSAGE_MAP(CMassSpecDoc, CDocument)
	//{{AFX_MSG_MAP(CMassSpecDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc construction/destruction

CMassSpecDoc::CMassSpecDoc()
{
}

CMassSpecDoc::~CMassSpecDoc()
{
	SaveDefMassTable();
}

BOOL CMassSpecDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc serialization

void CMassSpecDoc::Serialize(CArchive& ar)
{
	char Key[4]="msp";
	char DocVersion=1;
	if (ar.IsStoring())
	{
		ar.Write(&Key,3);
		ar << DocVersion;
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc diagnostics

#ifdef _DEBUG
void CMassSpecDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMassSpecDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc commands

void CMassSpecDoc::InitDoc()
{
	memset(m_MassTable,0,sizeof(m_MassTable));
	char EntryName[50];
	CString EntryContents;


	for(int i=0; i<MAX_MASS_COUNT;i++)
	{
		sprintf(EntryName, "Entry %i", i);
		EntryContents=theApp.GetProfileString("Mass Table", EntryName, "0, 0,"); 
	}
}

void CMassSpecDoc::SaveDefMassTable()
{
WriteProfileString("Mass Table", "Entry 0", "0, 0,"); 
}
