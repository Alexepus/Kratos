// ThermoData.cpp: implementation of the CThermoData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Spec.h"
#include "SpecView.h"
#include "ThermoHistDoc.h"
#include "MainFrame.h"
#include "Functions.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CThermoHistDoc::CThermoHistDoc()
{
}

CThermoHistDoc::~CThermoHistDoc()
{

}

CChartCtrl* CThermoHistDoc::GetChart()
{
	return m_pView->m_pChart;
}

BOOL CThermoHistDoc::IsThermoHistMode()
{
	return m_pView->m_bThermoChart;
}

void CThermoHistDoc::FormatChartToThermoHist()
{
	CChartCtrl* pChart=GetChart();
	pChart->RemoveAllCursors();
	pChart->RemoveAllSeries();
	pChart->GetBottomAxis()->SetMinMax(0,30);
	pChart->GetBottomAxis()->SetAutomaticMode(true,5.);
	pChart->GetBottomAxis()->SetAutomatic(true);
	pChart->GetBottomAxis()->SetTimeFormat(true,"M:ss.UU");
	pChart->GetLeftAxis()->SetAutomatic(true);
	pChart->GetLeftAxis()->GetLabel()->SetFont(90,"Microsoft Sans Serif");
	pChart->GetLeftAxis()->GetLabel()->SetText("Temperature, �C");
	pChart->GetLegend()->SetVisible(true);
	pChart->GetLegend()->SetFrameVisible(false);
	pChart->GetLegend()->SetAutoPosition(false);
	pChart->GetLegend()->SetUserPosition(CPoint(60,20));
	pChart->GetLegend()->SetFont(100,"Microsoft Sans Serif");
	pChart->AddSerie(CChartSerie::stLinePointsSerie);
	pChart->GetSerie(0)->GetAsLinePoints()->m_bShowPoints=TRUE;
	pChart->GetSerie(0)->GetAsLinePoints()->m_bShowLine=FALSE;
	pChart->GetSerie(0)->GetAsLinePoints()->m_PointsInnerColor=RGB(255,170,170);
	pChart->GetSerie(0)->SetName("Reference T");
	pChart->GetSerie(0)->m_bDrawLegendGalo=true;
	pChart->AddSerie(CChartSerie::stLinePointsSerie);
	pChart->GetSerie(1)->GetAsLinePoints()->m_bShowPoints=TRUE;
	pChart->GetSerie(1)->GetAsLinePoints()->m_PointsInnerColor=RGB(0,225,0);
	pChart->GetSerie(1)->SetName("Measured T");
	pChart->GetSerie(1)->m_bDrawLegendGalo=true;

	pChart->RefreshCtrl();

}

void CThermoHistDoc::RecieveNewMessage()
{
	CTempMessage Msg;
	CChartCtrl* pChart=GetChart();
	CMainFrame *pMainFrame=(CMainFrame*)theApp.m_pMainWnd;

	while(ThermoPlotQueue.try_front_pop(Msg))
	{
		if(Msg.PointType==CTempMessage::eRefTemp)
		{
			RefTemp.push_back(Msg.Pt);
			if(VerifyGUIObject(pMainFrame))
				pMainFrame->SetStatusTRef(Msg.Pt.Temp);
		}
		else
		{
			MeasTemp.push_back(Msg.Pt);
			if(VerifyGUIObject(pMainFrame))
				pMainFrame->SetStatusTCur(Msg.Pt.Temp);
		}
	}
	int a=RefTemp.size();
	if(IsThermoHistMode())
		RedrawChart();
}

void CThermoHistDoc::RedrawChart()
{
	CChartCtrl* pChart=GetChart();
	pChart->GetSerie(0)->ClearSerie(); //RefTemp
	pChart->GetSerie(1)->ClearSerie(); //MeasTemp
	double *TimeArray=new double[max(RefTemp.size(),MeasTemp.size())];
	double *TempArray=new double[max(RefTemp.size(),MeasTemp.size())];
	int i=0;
	
	for(std::deque<CTempPoint>::iterator iter=RefTemp.begin();iter!=RefTemp.end(); iter++)
	{
		TimeArray[i]=iter->Time;
		TempArray[i++]=iter->Temp;
	}
	pChart->GetSerie(0)->SetPoints(TimeArray,TempArray,i);
	
	i=0;
	for(iter=MeasTemp.begin();iter!=MeasTemp.end(); iter++)
	{
		TimeArray[i]=iter->Time;
		TempArray[i++]=iter->Temp;
	}
	pChart->GetSerie(1)->SetPoints(TimeArray,TempArray,i);

	delete[] TimeArray;
	delete[] TempArray;
	pChart->RefreshCtrl();
}
