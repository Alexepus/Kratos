#include "stdafx.h"
#include "Spec.h"
#include "SpecView.h"
#include "CamacUnits.h"
#include "VCMCDM.h"
#include "LogToFile.h"
#include "HSChart/ChartCtrl.h"

extern CSpecApp theApp;
#define SIMULATION

#define FromAdcCodeToV(Code) ((022000-Code/1<<theApp.m_Options.AdcIntegration.iVal)/(1.+15*theApp.m_Options.AdcRange.iVal)*0.001)

int CorrectedDeltaTicks(DWORD StartTicks, DWORD EndTicks)
{
if(EndTicks>StartTicks)
	return EndTicks-StartTicks;
else
	return 0-EndTicks+StartTicks;
}

UINT MeasuringThread(LPVOID pParam)
{
	CSpecView *pSpecView=(CSpecView *)pParam;
	CMassSpecDoc *pDoc=pSpecView->GetDocument();
	//Reading the INI file in the current folder:
	const int CrateN=GetPrivateProfileInt("CAMAC", "CrateNumber", 0,theApp.m_psIniFileName);
	const int DacN=GetPrivateProfileInt("CAMAC", "DacPosition", 1,theApp.m_psIniFileName);
	const int AdcN=GetPrivateProfileInt("CAMAC", "AdcPosition", 1,theApp.m_psIniFileName);
	int i, RegIndex=0, Wait, AdcValue=0;
	CChartSerie* SerieByReg[100];
	memset(SerieByReg,0,sizeof(SerieByReg));
	DWORD StartTime=GetTickCount();
	double Mass;
	#ifndef SIMULATION
	Camac_EnableMessage(FALSE); //camac driver won't display MessageBoxes
	Camac_Reset(CrateN);
	Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_WRITE_CONFIG_F, (CODE_D<<3)|CODE_T);
	Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_RESET_LAM_F, 0);
	#endif

	pSpecView->m_pChart->RemoveAllSeries();
	pSpecView->m_pChart->GetBottomAxis()->SetAutomatic(true);
	do
	{
		for(RegIndex=0; RegIndex<pDoc->m_MassTable.size(); RegIndex++)
		{
			if(!pDoc->m_MassTable[RegIndex].Checked || pDoc->m_MassTable[RegIndex].Mass<=0)
				continue;
			Mass=pDoc->m_MassTable[RegIndex].Mass;
			#ifndef SIMULATION
			Camac_WriteWord(CrateN, DacN, 0, DAC_WRITE, ToDac12Code(theApp.m_pMassCalibDoc->VoltageByMass(Mass)));
			#endif
			Sleep(theApp.m_Options.MassSetupDelay*1000);
			#ifndef SIMULATION
			Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_START_F, 0);
			#endif
			Sleep(5*(1<<theApp.m_Options.AdcIntegration.iVal)-5);
			#ifndef SIMULATION
			for(Wait=0; Wait<50; Wait++)
			{
				Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_TEST_LAM_F, 0);
				if(Camac_q())
					break;
				Sleep(1);
			}
			if(Wait==50)
				Msg("Failed wait for ADC LAM");
			AdcValue=Camac_ReadLong(CrateN, AdcN, ADC_A, ADC_READ_VOLTAGE_F);
			#else
			AdcValue=abs(AdcValue+rand()*1000/RAND_MAX-550);
			#endif
			if(!SerieByReg[RegIndex])
			{
				SerieByReg[RegIndex]=pSpecView->m_pChart->AddSerie(CChartSerie::stLinePointsSerie);
			}
			SerieByReg[RegIndex]->AddPoint(CorrectedDeltaTicks(StartTime,GetTickCount())*0.001, (double)FromAdcCodeToV(AdcValue));
		}
		pDoc->m_PassedCommonTime=CorrectedDeltaTicks(StartTime,GetTickCount());
		pDoc->SetModifiedFlag();
	}while(pSpecView->m_bMeasureStart && pDoc->m_PassedCommonTime<=pDoc->m_ScanTime);
	bool StoppedByUser=!pSpecView->m_bMeasureStart;
	pSpecView->m_bMeasureStart=FALSE;
	pSpecView->m_pList->EnableInput();
	if(StoppedByUser)
		theApp.m_pMainWnd->MessageBox("Measurement has been stopped.     ", "Spec", MB_OK|MB_ICONINFORMATION);
	else
		theApp.m_pMainWnd->MessageBox("Measurement has been completed.      ", "Spec", MB_OK|MB_ICONINFORMATION);

	return 0;
}