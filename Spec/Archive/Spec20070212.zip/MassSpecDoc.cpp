// MassSpecDoc.cpp : implementation of the CMassSpecDoc class
//

#include "stdafx.h"
#include "Spec.h"

#include "MassSpecDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSpecApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc

IMPLEMENT_DYNCREATE(CMassSpecDoc, CDocument)

BEGIN_MESSAGE_MAP(CMassSpecDoc, CDocument)
	//{{AFX_MSG_MAP(CMassSpecDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc construction/destruction

CMassSpecDoc::CMassSpecDoc()
{
}

CMassSpecDoc::~CMassSpecDoc()
{
	SaveDefData();
}

BOOL CMassSpecDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	InitDoc();
	if(IsWindow(theApp.m_pMainWnd->GetSafeHwnd()))
		theApp.m_pMainWnd->SetWindowText("Spec - Unsaved");

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc serialization

void CMassSpecDoc::Serialize(CArchive& ar)
{
	char Key[4]="msp";
	char DocVersion=1;
	if (ar.IsStoring())
	{
		ar.Write(&Key,3);
		ar << DocVersion;
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc diagnostics

#ifdef _DEBUG
void CMassSpecDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMassSpecDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMassSpecDoc commands

void CMassSpecDoc::InitDoc()
{
	char EntryName[50];
	char EntryContents[256];
	CMassTable Row;
	int i, Checked, EntryCount;
	m_MassTable.clear();

	GetPrivateProfileString("Mass Table", "EntryCount", "0", EntryContents, 256, theApp.m_psIniFileName);
	EntryCount=atoi(EntryContents);
	for(i=0; i<min(EntryCount,MAX_MASS_COUNT);i++)
	{
		sprintf(EntryName, "Entry_%.2i", i);
		GetPrivateProfileString("Mass Table", EntryName, "0, 0,", EntryContents, 256, theApp.m_psIniFileName);
		if(strcmp(EntryContents,"0, 0,")==0)
			break;
		memset(Row.Comments,0,sizeof(Row.Comments));
		sscanf(EntryContents, "%i,%i,%63c", &Checked, &Row.Mass, Row.Comments);
		Row.Checked=Checked;
		m_MassTable.push_back(Row);
	}
	GetPrivateProfileString("Default Doc", "ScanTime", "60", EntryContents, 256, theApp.m_psIniFileName);
	m_ScanTime=atoi(EntryContents);
	
}

void CMassSpecDoc::SaveDefData()
{
	char EntryName[50];
	char EntryContents[256];
	int j=0;
	for(int i=0; i<m_MassTable.size();i++)
	{
		CMassTable *pRow=&m_MassTable[i];
		if(pRow->Mass<=0)
			continue;
		sprintf(EntryName, "Entry_%.2i", j);
		sprintf(EntryContents, "%i,%i,%s", (int)pRow->Checked, pRow->Mass, pRow->Comments);
		WritePrivateProfileString("Mass Table", EntryName, EntryContents, theApp.m_psIniFileName);
		j++;
	}
	sprintf(EntryContents, "%i", j);
	WritePrivateProfileString("Mass Table", "EntryCount", EntryContents, theApp.m_psIniFileName);
	sprintf(EntryContents, "%i", m_ScanTime);
	WritePrivateProfileString("Default Doc", "ScanTime", EntryContents, theApp.m_psIniFileName);
}
