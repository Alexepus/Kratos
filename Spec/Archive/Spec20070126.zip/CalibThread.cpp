#include "stdafx.h"
#include "Spec.h"
#include "SpecView.h"
#include "CamacUnits.h"

extern CSpecApp theApp;

UINT CalibThread(LPVOID pParam)
{
CSpecView *pSpecView=(CSpecView *)pParam;
//Reading the INI file in the current folder:
const int CrateN=GetPrivateProfileInt("CAMAC", "CrateNumber", 0,theApp.m_psIniFileName);
const int DacN=GetPrivateProfileInt("CAMAC", "DacPosition", 1,theApp.m_psIniFileName);
const int AdcN=GetPrivateProfileInt("CAMAC", "AdcPosition", 1,theApp.m_psIniFileName);
int i, Wait;

#ifndef SIMULATION
Camac_EnableMessage(FALSE); //camac driver won't display MessageBoxes
Camac_Reset(CrateN);
Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_WRITE_CONFIG_F, (CODE_D<<3)|CODE_T);
Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_RESET_LAM_F, 0);
#endif
 
while(pSpecView->m_bMeasureStart)
{
	for(i=0;i<1024 && pSpecView->m_bMeasureStart; i+=5)
	{
		Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_START_F, 0);
		for(Wait=0; Wait<100; Wait++)
		{
			Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_TEST_LAM_F, 0);
			if(Camac_q())
				break;
			Sleep(1);
		}
		if(Wait==100)
			Msg("Failed wait for ADC LAM");
		Camac_ReadLong(CrateN, AdcN, ADC_A, ADC_WRITE_CONFIG_F);



	}


}


pSpecView->m_bMeasureStart=FALSE;
return 0;
}	