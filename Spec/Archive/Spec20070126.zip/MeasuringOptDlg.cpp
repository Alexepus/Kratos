// MeasuringOptDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Spec.h"
#include "MeasuringOptDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMeasuringOptDlg dialog


CMeasuringOptDlg::CMeasuringOptDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMeasuringOptDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMeasuringOptDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMeasuringOptDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMeasuringOptDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMeasuringOptDlg, CDialog)
	//{{AFX_MSG_MAP(CMeasuringOptDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMeasuringOptDlg message handlers
