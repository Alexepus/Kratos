#if !defined(AFX_XSPLITTERWND_H__C5D110ED_8246_474D_8456_379D8A691E17__INCLUDED_)
#define AFX_XSPLITTERWND_H__C5D110ED_8246_474D_8456_379D8A691E17__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// XSplitterWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CXSplitterWnd frame with splitter

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif


class CXSplitterWnd : public CSplitterWnd  
{
DECLARE_DYNCREATE(CXSplitterWnd)

public:
	void HideSplitter();
	CXSplitterWnd();
	virtual ~CXSplitterWnd();

	/*virtual int HitTest(CPoint pt) const{return 1;};//{return CSplitterWnd::HitTest(pt);};
	virtual void GetInsideRect(CRect& rect) const{};//{CSplitterWnd::GetInsideRect(rect);};
	virtual void GetHitRect(int ht, CRect& rect){};//{CSplitterWnd::GetHitRect(ht, rect);};
	virtual void TrackRowSize(int y, int row){};//{CSplitterWnd::TrackRowSize(y, row);};
	virtual void TrackColumnSize(int x, int col){};//{CSplitterWnd::TrackColumnSize(x, col);};
*/	void DrawAllSplitBars(CDC* pDC, int cxInside, int cyInside){};//{CSplitterWnd::DrawAllSplitBars(pDC, cxInside, cyInside);};
/*	virtual void SetSplitCursor(int ht){};//{CSplitterWnd::SetSplitCursor(ht);};

	// starting and stopping tracking
	//virtual void StartTracking(int ht){};//{CSplitterWnd::StartTracking(ht);};
	//virtual void StopTracking(BOOL bAccept){}//{CSplitterWnd::StopTracking(bAccept);};

	// special command routing to frame
	BOOL OnCommand(WPARAM wParam, LPARAM lParam){return CSplitterWnd::OnCommand(wParam, lParam);};
	BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult){return CSplitterWnd::OnNotify(wParam, lParam, pResult);};
*/
	// Generated message map functions
	//{{AFX_MSG(CYSplitterWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

#endif // !defined(AFX_XSPLITTERWND_H__5B2C9807_A25D_4301_BD4E_9718C3F66EAC__INCLUDED_)
