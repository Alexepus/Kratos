// SpecView.cpp : implementation of the CSpecView class
//

#include "stdafx.h"
#include "Spec.h"
#include "HSChart\\ChartCtrl.h"
#include "MassSpecDoc.h"
#include "SpecView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace std;
/////////////////////////////////////////////////////////////////////////////
// CSpecView

IMPLEMENT_DYNCREATE(CSpecView, CView)

BEGIN_MESSAGE_MAP(CSpecView, CView)
	//{{AFX_MSG_MAP(CSpecView)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpecView construction/destruction

CSpecView::CSpecView()
{
}

CSpecView::~CSpecView()
{
	delete m_pChart;
}

BOOL CSpecView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView drawing

void CSpecView::OnDraw(CDC* pDC)
{
	CMassSpecDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView printing

BOOL CSpecView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSpecView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CSpecView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView diagnostics

#ifdef _DEBUG
void CSpecView::AssertValid() const
{
	CView::AssertValid();
}

void CSpecView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMassSpecDoc* CSpecView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMassSpecDoc)));
	return (CMassSpecDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSpecView message handlers

BOOL CSpecView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	
	return 0;//CView::OnEraseBkgnd(pDC);
}

void CSpecView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	m_pChart->MoveWindow(0,0,cx,cy);
	
}

int CSpecView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	RECT rect={50,50,200,200};
	GetClientRect(&rect);
	m_pChart=new CChartCtrl;
	m_pChart->Create(this,rect,ID_CHART,
		WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE);//|WS_HSCROLL|WS_VSCROLL,
	m_pChart->SetEdgeType(0);//BDR_RAISEDOUTER
	
	return 0;
}
