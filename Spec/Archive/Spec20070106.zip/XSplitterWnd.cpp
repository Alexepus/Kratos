// XSplitterWnd.cpp: implementation of the CXSplitterWnd class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Spec.h"
#include "XSplitterWnd.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CXSplitterWnd, CSplitterWnd)

CXSplitterWnd::CXSplitterWnd()
{

}

CXSplitterWnd::~CXSplitterWnd()
{

}

BEGIN_MESSAGE_MAP(CXSplitterWnd, CSplitterWnd)
	//{{AFX_MSG_MAP(CXSplitterWnd)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CXSplitterWnd::HideSplitter()
{
m_cxBorderShare=0;
m_cxSplitterGap=-1;
m_cxSplitter=-1;
RecalcLayout();
}


