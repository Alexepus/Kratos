#if !defined(AFX_YSPLITTERWND_H__C5D110ED_8246_474D_8456_379D8A691E17__INCLUDED_)
#define AFX_YSPLITTERWND_H__C5D110ED_8246_474D_8456_379D8A691E17__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// YSplitterWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CYSplitterWnd frame with splitter

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CYSplitterWnd : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CYSplitterWnd)
protected:
	CYSplitterWnd();           // protected constructor used by dynamic creation

// Attributes
protected:
	CSplitterWnd    m_wndSplitter;
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CYSplitterWnd)
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CYSplitterWnd();

	// Generated message map functions
	//{{AFX_MSG(CYSplitterWnd)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_YSPLITTERWND_H__C5D110ED_8246_474D_8456_379D8A691E17__INCLUDED_)
