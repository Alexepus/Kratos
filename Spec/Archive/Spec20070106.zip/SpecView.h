// SpecView.h : interface of the CSpecView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPECVIEW_H__26AA1D20_E093_42CC_82EE_F4A17917C28A__INCLUDED_)
#define AFX_SPECVIEW_H__26AA1D20_E093_42CC_82EE_F4A17917C28A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CChartCtrl;
class CMassSpecDoc;
class CSpecView : public CView
{
protected: // create from serialization only
	CSpecView();
	DECLARE_DYNCREATE(CSpecView)

// Attributes
public:
	CMassSpecDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpecView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	CChartCtrl* m_pChart;
	virtual ~CSpecView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSpecView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SpecView.cpp
inline CMassSpecDoc* CSpecView::GetDocument()
   { return (CMassSpecDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPECVIEW_H__26AA1D20_E093_42CC_82EE_F4A17917C28A__INCLUDED_)
