BOOL ConfigureComPort(HANDLE hCommDev,int BaudRate);
int DetectSerialErrors(HANDLE hComm, CString *Err=NULL);
