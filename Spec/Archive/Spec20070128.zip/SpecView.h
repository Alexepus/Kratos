// SpecView.h : interface of the CSpecView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPECVIEW_H__26AA1D20_E093_42CC_82EE_F4A17917C28A__INCLUDED_)
#define AFX_SPECVIEW_H__26AA1D20_E093_42CC_82EE_F4A17917C28A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include"IniValues.h"
#include"CalibDlg.h"

class CChartCtrl;
class CReportCtrl;
class CMassSpecDoc;
class CSpecView : public CView
{
protected: // create from serialization only
	CSpecView();
	DECLARE_DYNCREATE(CSpecView)

// Attributes
public:
	CMassSpecDoc* GetDocument();
	SvLdInt m_bShowList;
	SvLdInt m_iListWidth;
	SvLdInt	m_iColumn0Width;
	SvLdInt	m_iColumn1Width;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpecView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL
	LRESULT OnListCheckBox(WPARAM WParam, LPARAM LParam);
// Implementation
public:
	void FillTable();
	volatile BOOL m_bMeasureStart;
	CCalibDlg* m_pCalibDlg;
	CRect m_CalibDlgRect;
	void OnButtonCalibOK();
	CButton* m_pButtonOK;
	HCURSOR m_hCursorDivSize;
	void DrawDivider(CDC* pDC=NULL);
	void ResizeClient(int x=-1, int y=-1);
	CPoint m_ClickPoint;
	CPoint m_LastPoint;
	BOOL m_bWasLButtonDown;
	BOOL m_bCalibration;
	CChartCtrl* m_pChart;
	CReportCtrl* m_pList;
	CRect m_rDivider;
	virtual ~CSpecView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSpecView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnViewMasses();
	afx_msg void OnUpdateViewMasses(CCmdUI* pCmdUI);
	afx_msg void OnSettingsCalibration();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnToolBarStart();
	afx_msg void OnUpdateToolBarButtonStart(CCmdUI* pCmdUI);
	afx_msg void OnToolBarStop();
	afx_msg void OnUpdateToolBarButtonStop(CCmdUI* pCmdUI);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SpecView.cpp
inline CMassSpecDoc* CSpecView::GetDocument()
   { return (CMassSpecDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPECVIEW_H__26AA1D20_E093_42CC_82EE_F4A17917C28A__INCLUDED_)
