// Spec.h : main header file for the SPEC application
//

#if !defined(AFX_SPEC_H__3AE50321_BAB5_484C_BE9F_70692B90ADE1__INCLUDED_)
#define AFX_SPEC_H__3AE50321_BAB5_484C_BE9F_70692B90ADE1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "MassCalibDoc.h"
#include "IniValues.h"

/////////////////////////////////////////////////////////////////////////////
// CSpecApp:
// See Spec.cpp for the implementation of this class
//
class COptionsData
{
public:
	SvLdDouble CalibMassStart;
	SvLdDouble CalibMassStop;
	SvLdDouble CalibMassStep;
	SvLdDouble MassSetupDelay;

	COptionsData()
	{
		CalibMassStart.Describe(0.,"Measuring Options", "CalibMassStart"); 
		CalibMassStop.Describe(50.,"Measuring Options", "CalibMassStop"); 
		CalibMassStep.Describe(0.25,"Measuring Options", "CalibMassStep"); 
		MassSetupDelay.Describe(0.001,"Measuring Options", "MassSetupDelay"); 
	};

};

class CSpecApp : public CWinApp
{
public:
	char* m_psIniFileName;
	CMassCalibDoc* m_pMassCalibDoc;
	COptionsData m_Options;
	CWinThread *m_pThread;
	CSpecApp();
	~CSpecApp();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpecApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CSpecApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

UINT CalibThread(LPVOID pParam);
UINT MeasuringThread(LPVOID pParam);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPEC_H__3AE50321_BAB5_484C_BE9F_70692B90ADE1__INCLUDED_)
