#include "stdafx.h"
#include "Spec.h"
#include "SpecView.h"
#include "CamacUnits.h"
#include "VCMCDM.h"
#include "LogToFile.h"
#include "HSChart/ChartCtrl.h"
#include "MainFrame.h"
#include "Threads.h"
#include "math.h"
#include "ComThread.h"

extern CSpecApp theApp;

UINT MeasuringThread(LPVOID pParam)
{
	CSpecView *pSpecView=(CSpecView *)pParam;
	CMassSpecDoc *pDoc=pSpecView->GetDocument();
	CMainFrame *pMainFrame=(CMainFrame*)theApp.m_pMainWnd;
	CWnd* pwnd=pSpecView->GetParent();
	//Reading the INI file in the current folder:
	int RegIndex=0;
	enum {StoppedByUser, MeasurementCompleted, NothingToMeasure, HardwareError, Unknown} eStopReason=Unknown;
	double Intensity,Time;
	CChartSerie* SerieByReg[100];
	memset(SerieByReg,0,sizeof(SerieByReg));
	double SeriesGage[100];
	memset(SeriesGage,0,sizeof(SeriesGage));
	DWORD StartTime=GetTickCount();
	double Mass;
	#ifdef SIMULATION
	double IntensitySim[50]={5,10,20,30,0,0};
	#endif
	
	bool bIsValidReg=false;
	for(RegIndex=0; RegIndex<pDoc->m_MassTable.size(); RegIndex++)
	{
		if(!pDoc->m_MassTable[RegIndex].Checked || pDoc->m_MassTable[RegIndex].Mass<=0)
			continue;
		bIsValidReg=true;
		break;
	}
	if(!bIsValidReg)
	{
		eStopReason=NothingToMeasure;
		goto FinishMeasure;
	}
	for(RegIndex=0; RegIndex<pDoc->m_MassTable.size(); RegIndex++)
	{
		pDoc->m_MassTable[RegIndex].vIntensity.clear();
		pDoc->m_MassTable[RegIndex].vTime.clear();
	}

	do
	{
		for(RegIndex=0; RegIndex<pDoc->m_MassTable.size(); RegIndex++)
		{
			if(!pDoc->m_MassTable[RegIndex].Checked || pDoc->m_MassTable[RegIndex].Mass<=0)
				continue;
			Mass=pDoc->m_MassTable[RegIndex].Mass;

			#ifndef SIMULATION
			if(!LoadMassDac(theApp.m_pMassCalibDoc->VoltageByMass(Mass)))
			{
				LogFile("MeasuringThread: LoadMassDac() failed");
				if(!LoadMassDac(theApp.m_pMassCalibDoc->VoltageByMass(Mass)))
				{
					eStopReason=HardwareError;
					goto FinishMeasure;
				}
			}
			#endif
			Sleep(theApp.Ini.MassSetupDelay*1000);
			#ifndef SIMULATION
			if(!GetMassIntensityAdc(Intensity))
			{
				LogFile("MeasuringThread: GetMassIntensityAdc() failed");
				if(!GetMassIntensityAdc(Intensity))
				{
					eStopReason=HardwareError;
					goto FinishMeasure;
				}
			}
			#else
			IntensitySim[RegIndex]=fabs(IntensitySim[RegIndex]+rand()*50./RAND_MAX-30);
			Intensity=IntensitySim[RegIndex];
			#endif
			Time=(GetTickCount()-StartTime)*0.001;
			if(pDoc->m_MassTable[RegIndex].vIntensity.empty())
			{
				pDoc->m_MassTable[RegIndex].IntensityMax=Intensity*2;
				pDoc->m_MassTable[RegIndex].bIntensityMaxChanged=true;
			}
			else if(Intensity>pDoc->m_MassTable[RegIndex].IntensityMax)
			{
				pDoc->m_MassTable[RegIndex].IntensityMax=Intensity;
				pDoc->m_MassTable[RegIndex].bIntensityMaxChanged=true;
			}
			pDoc->m_MassTable[RegIndex].vIntensity.push_back(Intensity);
			pDoc->m_MassTable[RegIndex].vTime.push_back(Time);
		}
		pDoc->m_vRefTemp.push_back(pSpecView->m_ThermoReg.m_Hist.LastRefTemp);
		pDoc->m_vMeasTemp.push_back(pSpecView->m_ThermoReg.m_Hist.LastMeasTemp);
		pDoc->m_PassedCommonTime=GetTickCount()-StartTime;
		pDoc->SetModifiedFlag();
		pSpecView->UpdateView();
		pMainFrame->SetStatusRemainTime((pDoc->m_ScanTime-pDoc->m_PassedCommonTime)*0.001);
	}while(pSpecView->m_bMeasureStart && pDoc->m_PassedCommonTime<=pDoc->m_ScanTime);
FinishMeasure:
	if(!pSpecView->m_bMeasureStart)
		eStopReason=StoppedByUser;
	pSpecView->m_bMeasureStart=FALSE;
	pSpecView->m_pList->EnableInput();
	pMainFrame->SetStatusRemainTime(0);

	switch(eStopReason)
	{
	case StoppedByUser:
		theApp.m_pMainWnd->MessageBox("Measurement has been stopped.     ", "Spec", MB_OK|MB_ICONINFORMATION);
		break;
	case NothingToMeasure:
		theApp.m_pMainWnd->MessageBox("There is no data to measure.      ", "Spec", MB_OK|MB_ICONINFORMATION);
		break;
	case HardwareError:
		theApp.m_pMainWnd->MessageBox("Error: controller does not respond.\nMeasurement has been stopped!       ", "Spec", MB_OK|MB_ICONINFORMATION);
		break;
	default:
		theApp.m_pMainWnd->MessageBox("Measurement has been completed.      ", "Spec", MB_OK|MB_ICONINFORMATION);
	}
	pDoc->m_bMeasurementInProgress=false;
	return 0;
}

bool LoadMassDac(double Voltage)
{
	int Val=Voltage/5.*0x3FFF;
	Val=MinMax(0,0x3FFF,Val);
	ComMsg msg;
	msg.Buf[0]=CMD_LOAD_DAC;
	msg.Buf[1]=1;
	msg.Buf[2]=(BYTE)Val;
	msg.Buf[3]=(BYTE)(Val>>8);
	msg.MsgSize=4;
	return theApp.m_SerialLink.SendWaitForReply(&msg);
}

bool GetMassIntensityAdc(double &Voltage)
{
	bool Ret;
	ComMsg msg;
	msg.Buf[0]=CMD_GET_MASS_ADC;
	msg.MsgSize=1;
	Ret=theApp.m_SerialLink.SendWaitForReply(&msg);
	Voltage=((int)msg.Buf[1]+((int)msg.Buf[2]<<8))*4.096/0x3FFF;
	return Ret;
}
