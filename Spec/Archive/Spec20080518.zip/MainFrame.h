// MainFrame.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRAME_H__C304ADF7_3A1B_484E_919D_C2B101CA93E6__INCLUDED_)
#define AFX_MAINFRAME_H__C304ADF7_3A1B_484E_919D_C2B101CA93E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "SpecView.h"
#include "MassSpecDoc.h"
#include "ThermoSettingsDlg.h"


class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetStatusPower(double Power, bool On=true);
	void SetStatusTRef(double TRef, bool On=true);
	void SetStatusTCur(double TCur, bool Known=true);
	void SetStatusRemainTime(double Time);
	CMassSpecDoc* m_pMassSpecDoc;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CToolBar    m_wndToolBarTR;
protected:  // control bar embedded members
	double m_dRemainTime;
	double m_dTRef;
	double m_dTCur;
// Generated message map functions
protected:
	afx_msg void OnUpdateStatusRemainTime(CCmdUI *pCmdUI);
	afx_msg void OnUpdateStatusCurTemp(CCmdUI *pCmdUI);
	afx_msg void OnUpdateStatusRefTemp(CCmdUI *pCmdUI);
	LRESULT OnRemoteDxpsState(WPARAM WParam, LPARAM LParam);
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSettingsHardware();
	afx_msg void OnClose();
	afx_msg void OnTrTrsettings();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRAME_H__C304ADF7_3A1B_484E_919D_C2B101CA93E6__INCLUDED_)
