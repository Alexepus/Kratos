#include "stdafx.h"
#include "Spec.h"
#include "SpecView.h"
#include "CamacUnits.h"
#include "VCMCDM.h"
#include "LogToFile.h"
#include "HSChart/ChartCtrl.h"
#include "MainFrame.h"
#include "Threads.h"
#include "math.h"

extern CSpecApp theApp;

#define FromAdcCodeToV(Code) ((022000-Code/(1<<theApp.Ini.AdcIntegration))/(1.+15*theApp.Ini.AdcRange)*0.001)

int CorrectedDeltaTicks(DWORD StartTicks, DWORD EndTicks)
{
if(EndTicks>StartTicks)
	return EndTicks-StartTicks;
else
	return 0-EndTicks+StartTicks;
}

UINT MeasuringThread(LPVOID pParam)
{
	CSpecView *pSpecView=(CSpecView *)pParam;
	CMassSpecDoc *pDoc=pSpecView->GetDocument();
	CMainFrame *pMainFrame=(CMainFrame*)theApp.m_pMainWnd;
	CWnd* pwnd=pSpecView->GetParent();
	//Reading the INI file in the current folder:
	const int CrateN=GetPrivateProfileInt("CAMAC", "CrateNumber", 0,theApp.m_psIniFileName);
	const int DacN=GetPrivateProfileInt("CAMAC", "DacPosition", 1,theApp.m_psIniFileName);
	const int AdcN=GetPrivateProfileInt("CAMAC", "AdcPosition", 1,theApp.m_psIniFileName);
	int RegIndex=0, AdcValue=0;
	enum {StoppedByUser, MeasurementCompleted, NothingToMeasure, Unknown} eStopReason=Unknown;
	double Intensity,Time;
	CChartSerie* SerieByReg[100];
	memset(SerieByReg,0,sizeof(SerieByReg));
	double SeriesGage[100];
	memset(SeriesGage,0,sizeof(SeriesGage));
	DWORD StartTime=GetTickCount();
	double Mass;
	#ifndef SIMULATION
	Camac_EnableMessage(FALSE); //camac driver won't display MessageBoxes
	Camac_Reset(CrateN);
	Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_WRITE_CONFIG_F, (theApp.Ini.AdcRange<<3)|theApp.Ini.AdcIntegration);
	Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_RESET_LAM_F, 0);
	#else
	double IntensitySim[50]={5,10,20,30,0,0};
	#endif
	
	pSpecView->m_pChart->RemoveAllCursors();
	pSpecView->m_pChart->RemoveAllSeries();
	pSpecView->m_pChart->GetBottomAxis()->SetMinMax(0,30);
	pSpecView->m_pChart->GetBottomAxis()->SetAutomaticMode(true,5.);
	pSpecView->m_pChart->GetBottomAxis()->SetAutomatic(true);
	pSpecView->m_pChart->GetBottomAxis()->SetTimeFormat(true,"M:ss.U");
	pSpecView->m_pChart->GetLeftAxis()->SetAutomatic(false);
	pSpecView->m_pChart->GetLeftAxis()->SetMinMax(0,100.);
	pSpecView->m_pChart->GetLegend()->SetVisible(true);
	pSpecView->m_pChart->GetLegend()->SetFrameVisible(false);
	pSpecView->m_pChart->GetLegend()->SetAutoPosition(false);
	pSpecView->m_pChart->GetLegend()->SetUserPosition(CPoint(40,20));
	pSpecView->m_pChart->GetLegend()->SetFont(100,"Microsoft Sans Serif");
	pSpecView->m_pChart->RefreshCtrl();
	bool bIsValidReg=false;
	for(RegIndex=0; RegIndex<pDoc->m_MassTable.size(); RegIndex++)
	{
		if(!pDoc->m_MassTable[RegIndex].Checked || pDoc->m_MassTable[RegIndex].Mass<=0)
			continue;
		bIsValidReg=true;
		break;
	}
	if(!bIsValidReg)
	{
		eStopReason=NothingToMeasure;
		goto FinishMeasure;
	}
	for(RegIndex=0; RegIndex<pDoc->m_MassTable.size(); RegIndex++)
	{
		pDoc->m_MassTable[RegIndex].vIntensity.clear();
		pDoc->m_MassTable[RegIndex].vTime.clear();
	}

	do
	{
		for(RegIndex=0; RegIndex<pDoc->m_MassTable.size(); RegIndex++)
		{
			if(!pDoc->m_MassTable[RegIndex].Checked || pDoc->m_MassTable[RegIndex].Mass<=0)
				continue;
			Mass=pDoc->m_MassTable[RegIndex].Mass;
			#ifndef SIMULATION
			Camac_WriteWord(CrateN, DacN, 0, DAC_WRITE, ToDac12Code(theApp.m_pMassCalibDoc->VoltageByMass(Mass)));
			#endif
			Sleep(theApp.Ini.MassSetupDelay*1000);
			#ifndef SIMULATION
			Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_START_F, 0);
			#endif
			Sleep(5*(1<<theApp.Ini.AdcIntegration)-5);
			#ifndef SIMULATION
			int Wait;
			for(Wait=0; Wait<50; Wait++)
			{
				Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_TEST_LAM_F, 0);
				if(Camac_q())
					break;
				Sleep(1);
			}
			if(Wait==50)
				Msg("Failed wait for ADC LAM");
			AdcValue=Camac_ReadLong(CrateN, AdcN, ADC_A, ADC_READ_VOLTAGE_F);
			Intensity=(double)FromAdcCodeToV(AdcValue);
			#else
			IntensitySim[RegIndex]=fabs(IntensitySim[RegIndex]+rand()*50./RAND_MAX-30);
			Intensity=IntensitySim[RegIndex];
			#endif
			Time=CorrectedDeltaTicks(StartTime,GetTickCount())*0.001;
			pDoc->m_MassTable[RegIndex].vIntensity.push_back(Intensity);
			pDoc->m_MassTable[RegIndex].vTime.push_back(Time);

			if(!SerieByReg[RegIndex])
			{
				char str[50];
				SerieByReg[RegIndex]=pSpecView->m_pChart->AddSerie(CChartSerie::stLinePointsSerie);
				if(Intensity<=0) Intensity=1e-100;
				SeriesGage[RegIndex]=Intensity*2;
				sprintf(str,"Mass %i, 100%%=%.2f", pDoc->m_MassTable[RegIndex].Mass,SeriesGage[RegIndex]);
				SerieByReg[RegIndex]->SetName(str);
				pSpecView->m_pChart->RefreshCtrl();
			}
			if(Intensity>SeriesGage[RegIndex])
			{
				for(int i=0;i<SerieByReg[RegIndex]->GetPointsCount();i++)
				{
					SerieByReg[RegIndex]->SetYPointValue(i,SerieByReg[RegIndex]->GetYPointValue(i)*SeriesGage[RegIndex]/Intensity);
				}

				SeriesGage[RegIndex]=Intensity;
				char str[50];
				sprintf(str,"Mass %i, 100%%=%.2f", pDoc->m_MassTable[RegIndex].Mass,SeriesGage[RegIndex]);
				SerieByReg[RegIndex]->SetName(str);
				pSpecView->m_pChart->RefreshCtrl();
			}
			SerieByReg[RegIndex]->AddPoint(Time, Intensity/SeriesGage[RegIndex]*100);
		}
		pDoc->m_PassedCommonTime=CorrectedDeltaTicks(StartTime,GetTickCount());
		pDoc->SetModifiedFlag();
		pMainFrame->SetStatusRemainTime((pDoc->m_ScanTime-pDoc->m_PassedCommonTime)*0.001);
	}while(pSpecView->m_bMeasureStart && pDoc->m_PassedCommonTime<=pDoc->m_ScanTime);
FinishMeasure:
	if(!pSpecView->m_bMeasureStart)
		eStopReason=StoppedByUser;
	pSpecView->m_bMeasureStart=FALSE;
	pSpecView->m_pList->EnableInput();
	pMainFrame->SetStatusRemainTime(0);

	switch(eStopReason)
	{
	case StoppedByUser:
		theApp.m_pMainWnd->MessageBox("Measurement has been stopped.     ", "Spec", MB_OK|MB_ICONINFORMATION);
		break;
	case NothingToMeasure:
		theApp.m_pMainWnd->MessageBox("There is no data to measure.      ", "Spec", MB_OK|MB_ICONINFORMATION);
		break;
	default:
		theApp.m_pMainWnd->MessageBox("Measurement has been completed.      ", "Spec", MB_OK|MB_ICONINFORMATION);
	}
	return 0;
}