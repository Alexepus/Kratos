// SpecView.cpp : implementation of the CSpecView class
//

#include "stdafx.h"
#include "Spec.h"
#include "HSChart\\ChartCtrl.h"
#include "ReportCtrl.h"
#include "MassSpecDoc.h"
#include "SpecView.h"
#include "MainFrame.h"
#include "LogToFile.h"
#include "Approx.h"
#include "AppearSetupDlg.h"
#include "Threads.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSpecApp theApp;

using namespace std;
/////////////////////////////////////////////////////////////////////////////
// CSpecView

IMPLEMENT_DYNCREATE(CSpecView, CView)

BEGIN_MESSAGE_MAP(CSpecView, CView)
	//{{AFX_MSG_MAP(CSpecView)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_VIEW_MASSES, OnViewMasses)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MASSES, OnUpdateViewMasses)
	ON_COMMAND(ID_SETTINGS_CALIBRATION, OnSettingsCalibration)
	ON_WM_TIMER()
	ON_COMMAND(ID_BUTTON_START, OnToolBarStart)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_START, OnUpdateToolBarButtonStart)
	ON_COMMAND(ID_BUTTON_STOP, OnToolBarStop)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_STOP, OnUpdateToolBarButtonStop)
	ON_WM_DESTROY()
	ON_COMMAND(ID_SETTINGS_APPEARANCE, OnSettingsAppearance)
	ON_COMMAND(ID_VIEW_MASSCHART, OnViewMassChart)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MASSCHART, OnUpdateViewMassChart)
	ON_COMMAND(ID_VIEW_TEMPERATURECHART, OnViewTemperatureChart)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TEMPERATURECHART, OnUpdateViewTemperatureChart)
	ON_COMMAND(ID_TR_START, OnTrStart)
	ON_COMMAND(ID_TR_WAIT, OnTrWait)
	ON_COMMAND(ID_TR_WAIT_CONT, OnTrWaitCont)
	ON_COMMAND(ID_TR_CONTINUE, OnTrContinue)
	ON_COMMAND(ID_TR_MAINOFF, OnTrMainOff)
	ON_COMMAND(ID_TR_PRIME, OnTrPrime)
	ON_COMMAND(ID_TR_GO, OnTrGo)
	ON_UPDATE_COMMAND_UI(ID_TR_GO, OnUpdateTrGo)
	ON_UPDATE_COMMAND_UI(ID_TR_MAINOFF, OnUpdateTrMainoff)
	ON_UPDATE_COMMAND_UI(ID_TR_PRIME, OnUpdateTrPrime)
	ON_UPDATE_COMMAND_UI(ID_TR_START, OnUpdateTrStart)
	ON_UPDATE_COMMAND_UI(ID_TR_WAIT, OnUpdateTrWait)
	ON_UPDATE_COMMAND_UI(ID_TR_WAIT_CONT, OnUpdateTrWaitCont)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_MESSAGE(WM_ON_CHKBOX, OnListCheckBox)
	ON_MESSAGE(WM_ITEM_SORTED, OnListItemSorted)
	ON_MESSAGE(WM_EDIT_COMMITTED, OnListEditCommited)
	ON_MESSAGE(WM_UPDATE_THERMO_DATA, OnThermoRecieveNewMessage)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpecView construction/destruction
//CSpecView::
CSpecView::CSpecView()
{
	m_bShowList.Describe(TRUE,"View","ShowList");
	m_iListWidth.Describe(100,"View","ListWidth");
	m_iColumn0Width.Describe(60,"View","Column0Width");
	m_iColumn1Width.Describe(60,"View","Column1Width");
	m_bWasLButtonDown=FALSE;
	m_bCalibration=FALSE;
	m_bThermoChart=FALSE;
	m_bMeasureStart=FALSE;
	m_hCursorDivSize=AfxGetApp()->LoadCursor(IDC_CURSOR_DIVSIZE);
	m_ThermoHist.m_pView=this;
}

CSpecView::~CSpecView()
{
	delete m_pChart;
	delete m_pList;
}

BOOL CSpecView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView drawing

void CSpecView::OnDraw(CDC* pDC)
{
	CMassSpecDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	DrawDivider(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView printing

BOOL CSpecView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSpecView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CSpecView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CSpecView diagnostics

#ifdef _DEBUG
void CSpecView::AssertValid() const
{
	CView::AssertValid();
}

void CSpecView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMassSpecDoc* CSpecView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMassSpecDoc)));
	return (CMassSpecDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSpecView message handlers

BOOL CSpecView::OnEraseBkgnd(CDC* pDC) 
{
	return 0;//CView::OnEraseBkgnd(pDC);
}

void CSpecView::OnSize(UINT nType, int cx, int cy) 
{
	if(nType!=SIZE_RESTORED)
		return;
	CView::OnSize(nType, cx, cy);
	ResizeClient(cx,cy);
}

int CSpecView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	//SetTimer(1,1000,NULL);
	RECT rect={50,50,100,100};
	GetClientRect(&rect);
	m_pChart=new CChartCtrl;
	m_pChart->Create(this,rect,ID_CHART,
		WS_CHILD|WS_CLIPCHILDREN|WS_VISIBLE);//|WS_HSCROLL|WS_VSCROLL,
	m_pChart->SetEdgeType(0);//BDR_RAISEDOUTER
	m_pChart->GetBottomAxis()->SetMinMax(0,50);
	m_pChart->GetBottomAxis()->SetMinMax(0,30);
	m_pChart->GetBottomAxis()->SetAutomaticMode(true,5.);
	m_pChart->GetBottomAxis()->SetAutomatic(true);
	m_pChart->GetBottomAxis()->SetTimeFormat(true,"M:ss");
	m_pChart->GetLeftAxis()->SetAutomatic(false);
	m_pChart->GetLeftAxis()->SetMinMax(0,100.);

	m_pList=new CReportCtrl;
	m_pList->Create(this, ID_LIST, &rect);
	m_pList->ModifyStyle(0,LVS_SHOWSELALWAYS | WS_BORDER | WS_TABSTOP);
	m_pList->SetExtendedStyle(LVS_EX_GRIDLINES);
	m_pList->SetCheckboxeStyle();
	m_pList->InsertColumn(0,"Mass", LVCFMT_LEFT,m_iColumn0Width);
	m_pList->SetEditable(TRUE,-1,0);
	m_pList->InsertColumn(1,"Comments", LVCFMT_LEFT,m_iColumn1Width);
	m_pList->SetEditable(TRUE,-1,1);

	m_pCalibDlg=new CCalibDlg;
	m_pCalibDlg->Create(IDD_CALIB_DLG, this);
	m_pCalibDlg->m_pSpecView=this;

	DWORD ThreadId;
	theApp.m_hThermoRegThread=CreateThread(NULL,NULL, HeatingThread, this, NULL, &ThreadId);
	theApp.m_SerialLink.ReconnectCom("COM1");

	ComMsg msg;
	msg.Buf[0]=0xA1;
	msg.Buf[1]=0xA2;
	msg.MsgSize=2;
	msg.WaitForReply=true;
	theApp.m_SerialLink.SendComMessage(msg);
	return 0;
}

/*void CSpecView::OnLButtonClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rect=m_rDivider;
	rect.InflateRect(1,0);
	if(rect.PtInRect(point))
	{
		m_bShowList=FALSE;
		RECT rect={50,50,200,200};
		GetClientRect(&rect);
		OnSize(SIZE_RESTORED,rect.right, rect.bottom);
		UpdateWindow();

	}
	CView::OnLButtonDblClk(nFlags, point);
}*/

void CSpecView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_bWasLButtonDown)
	{
		CRect rect;
		GetClientRect(&rect);
		m_iListWidth=m_iListWidth.iVal+m_LastPoint.x-point.x;
		m_LastPoint=point;
		if(m_iListWidth.iVal<0)
		{
			m_iListWidth.iVal=0;
			m_LastPoint.x=rect.Width()-3;
		}
		if(m_iListWidth.iVal>rect.Width()-5)
		{
			m_iListWidth.iVal=rect.Width()-5;
			m_LastPoint.x=3;
		}

		ResizeClient();
		UpdateWindow();
	}
	else
	{
		if(m_rDivider.PtInRect(point))
			SetCursor(m_hCursorDivSize);
		//else
			////SetCursor(AfxGetApp()->LoadStandardCursor(IDC_ARROW));
	}
	CView::OnMouseMove(nFlags, point);
}

void CSpecView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_ClickPoint=point;
	m_LastPoint=point;

	if(m_rDivider.PtInRect(point))
	{
		SetCapture();
		SetCursor(m_hCursorDivSize);
		m_bWasLButtonDown=TRUE;
	}
	CView::OnLButtonUp(nFlags, point);
}

void CSpecView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_rDivider.PtInRect(point)&&m_rDivider.PtInRect(m_ClickPoint) && 
		(abs(m_ClickPoint.x-point.x)<=1) && (abs(m_ClickPoint.y-point.y)<=1))
	{
		m_bShowList=FALSE;
		ResizeClient();
		UpdateWindow();
	}
	m_bWasLButtonDown=FALSE;
	ReleaseCapture();
	CView::OnLButtonDown(nFlags, point);
}

void CSpecView::OnViewMasses() 
{
	m_bShowList=!(BOOL)m_bShowList;
	RECT rect={50,50,200,200};
	ResizeClient();
	UpdateWindow();

}

void CSpecView::OnUpdateViewMasses(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bShowList);
}

void CSpecView::ResizeClient(int x, int y)
{
	//����� ������� ���������� ������� �������������
	if(x==-1 && y==-1)
	{
		RECT rect;
		GetClientRect(&rect);
		x=rect.right;
		y=rect.bottom;
	}
	if(m_bThermoChart)
	{
		m_pCalibDlg->ShowWindow(SW_HIDE);
		m_pList->ShowWindow(SW_HIDE);
		m_rDivider.right=x;
		m_rDivider.left=m_rDivider.right;
	}
	else if(m_bCalibration)
	{
		m_rDivider.right=x-m_iListWidth.iVal;
		m_rDivider.left=m_rDivider.right-5;
		m_rDivider.top=0;
		m_rDivider.bottom=y;
		m_pList->ShowWindow(SW_HIDE);
		m_CalibDlgRect.left=m_rDivider.right;
		m_CalibDlgRect.top=0;
		m_CalibDlgRect.right=x;
		m_CalibDlgRect.bottom=y;
		m_pCalibDlg->MoveWindow(m_CalibDlgRect);
		m_pCalibDlg->ShowWindow(SW_SHOW);
		DrawDivider();
		UpdateWindow();
	}
	else if((BOOL)m_bShowList)
	{
		m_pCalibDlg->ShowWindow(SW_HIDE);
		m_rDivider.right=x-m_iListWidth.iVal;
		m_rDivider.left=m_rDivider.right-5;
		m_rDivider.top=0;
		m_rDivider.bottom=y;
		m_pList->ShowWindow(SW_SHOW);
		//m_pList->SetFocus();
		m_pList->MoveWindow(m_rDivider.right,0,x-m_rDivider.right,y);
		DrawDivider();
	}
	else
	{
		m_pCalibDlg->ShowWindow(SW_HIDE);
		m_pList->ShowWindow(SW_HIDE);
		m_rDivider.right=x;
		m_rDivider.left=m_rDivider.right;
		//m_pButtonOK->ShowWindow(SW_HIDE);
	}
	m_pChart->MoveWindow(0,0,m_rDivider.left,y);
}

void CSpecView::DrawDivider(CDC *pDC)
{
	if(pDC==NULL)
		pDC=GetDC();
	if(m_rDivider.Width()>0)
	{
		CBrush NewBrush(GetSysColor(COLOR_BTNFACE));
		CPen NewPen(PS_SOLID,1,GetSysColor(COLOR_BTNFACE));
		CBrush *pOldBrush=pDC->SelectObject(&NewBrush);
		CPen *pOldPen=pDC->SelectObject(&NewPen);

		pDC->Rectangle(m_rDivider);
		m_rDivider.bottom+=1;m_rDivider.top-=1;
		pDC->Draw3dRect(m_rDivider.left,m_rDivider.top-1,m_rDivider.Width(),m_rDivider.Height()+2,GetSysColor(COLOR_3DHILIGHT),GetSysColor(COLOR_BTNSHADOW));
		pDC->SelectObject(pOldBrush);
		pDC->SelectObject(pOldPen);
	}

}

BOOL CSpecView::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	int wNotifyCode = HIWORD(wParam); // notification code 
	int wID = LOWORD(wParam);         // item, control, or accelerator identifier 
	HWND hwndCtl = (HWND) lParam;      // handle of control
	int a=0;
	switch (wID)
	{
	case ID_CHART:
		break;
	case ID_LIST:
		break;
	}
//MessageBeep(MB_ICONQUESTION);

	return CView::OnCommand(wParam, lParam);
}

void CSpecView::OnSettingsCalibration() 
{
	m_bCalibration=TRUE;
	ResizeClient();
}

void CSpecView::OnButtonCalibOK()
{
	m_bCalibration=FALSE;
	ResizeClient();
	FormatChartToMassHist();
	RedrawChart();
}



BOOL CSpecView::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
	NMHDR *pnmh = (LPNMHDR) lParam;
	if(pnmh->code==NM_CLICK)//||pnmh->code==NM_SETFOCUS
	{
		LPNMITEMACTIVATE lpnmitem = (LPNMITEMACTIVATE) pnmh;
		if(lpnmitem->iItem<0 && lpnmitem->iSubItem>=0)
		{	int Items=m_pList->GetItemCount();
			m_pList->InsertItem(Items,"");
			m_pList->SetItemState(Items, LVIS_FOCUSED|LVIS_SELECTED, LVIS_FOCUSED|LVIS_SELECTED); 
			{
				CMassTable EmptyRow;
				EmptyRow.Checked=false;
				EmptyRow.Mass=0;
				memset(EmptyRow.Comments,0,sizeof(EmptyRow.Comments));
				GetDocument()->m_MassTable.insert(GetDocument()->m_MassTable.begin()+Items,EmptyRow);
			}

		
		}
	}
	if(pnmh->code==LVN_KEYDOWN)
	{
		LV_KEYDOWN* pLVKeyDown = (LV_KEYDOWN*)lParam;

		if((pLVKeyDown->wVKey==VK_DELETE) && !m_pList->IsUnderEdit() &&m_pList->GetEnableInput())
		{
			for(int i=0; i<m_pList->GetItemCount(); i++)
				if((m_pList->GetItemStates(i)&(RC_ITEM_FOCUSED|RC_ITEM_SELECTED))==(RC_ITEM_FOCUSED|RC_ITEM_SELECTED))
				{
					char EntryContents[256];
					m_pList->GetItemText(i,0,EntryContents,255);
					if(atoi(EntryContents)>0)
						GetDocument()->SetModifiedFlag();
					m_pList->DeleteItem(i);
					GetDocument()->m_MassTable.erase(GetDocument()->m_MassTable.begin()+i);
					break;
				}
		}

		if((pLVKeyDown->wVKey==VK_INSERT) && !m_pList->IsUnderEdit() &&m_pList->GetEnableInput())
		{
			for(int i=0; i<m_pList->GetItemCount(); i++)
				if((m_pList->GetItemStates(i)&(RC_ITEM_FOCUSED|RC_ITEM_SELECTED))==(RC_ITEM_FOCUSED|RC_ITEM_SELECTED))
				{
					m_pList->InsertItem(i,"");
					m_pList->SetItemStates(i+1,RC_ITEM_UNSELECTED);
					m_pList->SetItemStates(i,RC_ITEM_FOCUSED|RC_ITEM_SELECTED);
					{
						CMassTable EmptyRow;
						EmptyRow.Checked=false;
						EmptyRow.Mass=0;
						memset(EmptyRow.Comments,0,sizeof(EmptyRow.Comments));
						int size=GetDocument()->m_MassTable.size();
						GetDocument()->m_MassTable.insert(GetDocument()->m_MassTable.begin()+i,EmptyRow);
					}
					break;
				}
		}
		*pResult = 0;
	}
	if(pnmh->code==HDN_ENDTRACK)
	{
		LVCOLUMN col;
		col.mask = LVCF_WIDTH;
		if (m_pList->GetColumn(0, &col))
		   m_iColumn0Width=max(5,col.cx);
		if (m_pList->GetColumn(1, &col))
		   m_iColumn1Width=max(5,col.cx);
	}
//LogFileFormat("hwndFrom:0x%X, idFrom:%i, code:%i", pnmh->hwndFrom, pnmh->idFrom, pnmh->code);
	return CView::OnNotify(wParam, lParam, pResult);
}

LRESULT CSpecView::OnListCheckBox(WPARAM WParam, LPARAM LParam)
{
	int ItemIndex=WParam;
	char EntryContents[256];
	CMassTable Row=GetDocument()->m_MassTable[ItemIndex];
	if(Row.Mass<=0)
		return (LRESULT)0;
	m_pList->GetItemText(ItemIndex,0,EntryContents,255);
	ASSERT(Row.Mass==atoi(EntryContents));
	Row.Checked=m_pList->GetItemStates(ItemIndex)&RC_ITEM_CHECKED;
	GetDocument()->m_MassTable[ItemIndex]=Row;
	GetDocument()->SetModifiedFlag();
	return (LRESULT)0;
}
 
LRESULT CSpecView::OnListItemSorted(WPARAM WParam, LPARAM LParam)
{
//MessageBeep(MB_ICONQUESTION);
 return (LRESULT)0;
}
 
LRESULT CSpecView::OnListEditCommited(WPARAM WParam, LPARAM LParam)
{
	int ItemIndex=WParam;
	int ColumnIndex=LParam;

	char EntryContents[256];

	while(GetDocument()->m_MassTable.size()<=ItemIndex)
	{
		CMassTable EmptyRow;
		EmptyRow.Checked=false;
		EmptyRow.Mass=0;
		memset(EmptyRow.Comments,0,sizeof(EmptyRow.Comments));
		GetDocument()->m_MassTable.push_back(EmptyRow);
	}
	int size=GetDocument()->m_MassTable.size();
	GetDocument()->m_MassTable[ItemIndex].Checked=m_pList->GetItemStates(ItemIndex)&RC_ITEM_CHECKED;
	m_pList->GetItemText(ItemIndex,0,EntryContents,255);
	GetDocument()->m_MassTable[ItemIndex].Mass=atoi(EntryContents);
	m_pList->GetItemText(ItemIndex,1,GetDocument()->m_MassTable[ItemIndex].Comments,63);

	GetDocument()->SetModifiedFlag();
	return (LRESULT)0;
} 

void CSpecView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	//LogFileFormat("Capture=0x%X, View hWnd=%x, List hWnd=%x, Graph hWnd=%x", (GetCapture()==0)?0:GetCapture()->m_hWnd,m_hWnd, m_pList->m_hWnd, m_pChart->m_hWnd);
	
	CView::OnTimer(nIDEvent);
}

void CSpecView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	if(IsWindow(theApp.m_pMainWnd->GetSafeHwnd()))
		GetDocument()->SetTitle(NULL);

	FillTable();
	m_bCalibration=FALSE;
	m_bThermoChart=FALSE;
	ResizeClient();
	FormatChartToMassHist();
	RedrawChart();
}

void CSpecView::OnToolBarStart() 
{
	if(!m_bMeasureStart)
	{
		m_bMeasureStart=TRUE;
		if(m_bCalibration)
			theApp.m_pThread=AfxBeginThread(CalibThread,this);
		else
		{
			m_pList->EnableInput(false);
			theApp.m_pThread=AfxBeginThread(MeasuringThread,this);
		}
	}
}

void CSpecView::OnUpdateToolBarButtonStart(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bMeasureStart);

	
}

void CSpecView::OnToolBarStop() 
{
	m_bMeasureStart=FALSE;	
	m_pList->EnableInput(true);
}

void CSpecView::OnUpdateToolBarButtonStop(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!m_bMeasureStart);
	
}

void CSpecView::FillTable()
{
	CMassSpecDoc *pDoc=GetDocument();
	m_pList->DeleteAllItems();
	CString str;
	for(int i=0; i<pDoc->m_MassTable.size(); i++)
	{
		str.Format("%i", pDoc->m_MassTable[i].Mass);
		m_pList->InsertItem(i,(LPCSTR)str);
		m_pList->SetCheck(i, pDoc->m_MassTable[i].Checked);
		m_pList->SetItemText(i,1,pDoc->m_MassTable[i].Comments);
	}

}

void CSpecView::OnDestroy() 
{
	CView::OnDestroy();

}

void CSpecView::OnSettingsAppearance() 
{
	CAppearSetupDlg dlg;
	dlg.DoModal();
}

void CSpecView::RedrawChart()
{	
	CMassSpecDoc* pDoc=GetDocument();
	m_pChart->RemoveAllSeries();
	for(int RegIndex=0; RegIndex<pDoc->m_MassTable.size();RegIndex++)
	{
		if(pDoc->m_MassTable[RegIndex].vTime.size()==0)
			continue;
		char str[50];
		CChartSerie* pSerie=m_pChart->AddSerie(CChartSerie::stLinePointsSerie);
		pSerie->m_bDrawLegendGalo=true;
		double SeriesGage=pDoc->m_MassTable[RegIndex].vIntensity[0]*2;
		double *Time=new double[pDoc->m_MassTable[RegIndex].vTime.size()];
		double *Intensity=new double[pDoc->m_MassTable[RegIndex].vIntensity.size()];
		for(int i=0;i<pDoc->m_MassTable[RegIndex].vTime.size();i++)
		{
			Time[i]=pDoc->m_MassTable[RegIndex].vTime[i];
			Intensity[i]=pDoc->m_MassTable[RegIndex].vIntensity[i];
			if(Intensity[i]>SeriesGage)
				SeriesGage=Intensity[i];
		}
		if(SeriesGage==0) SeriesGage=1e-100;
		for(i=0;i<pDoc->m_MassTable[RegIndex].vTime.size();i++)
		{
			Intensity[i]*=100/SeriesGage;
		}
		pSerie->SetPoints(Time,Intensity,pDoc->m_MassTable[RegIndex].vTime.size());
		delete[] Time;
		delete[] Intensity;
		sprintf(str,"Mass %i, 100%%=%.2f", pDoc->m_MassTable[RegIndex].Mass,SeriesGage);
		pSerie->SetName(str);
	}
	m_pChart->RefreshCtrl();

}

void CSpecView::FormatChartToMassHist()
{
	m_pChart->RemoveAllCursors();
	m_pChart->RemoveAllSeries();
	m_pChart->GetBottomAxis()->SetMinMax(0,30);
	m_pChart->GetBottomAxis()->SetAutomaticMode(true,5.);
	m_pChart->GetBottomAxis()->SetAutomatic(true);
	m_pChart->GetBottomAxis()->SetTimeFormat(true,"M:ss");
	m_pChart->GetLeftAxis()->SetAutomatic(false);
	m_pChart->GetLeftAxis()->SetMinMax(0,100.);
	m_pChart->GetLegend()->SetVisible(true);
	m_pChart->GetLegend()->SetFrameVisible(false);
	m_pChart->GetLegend()->SetAutoPosition(false);
	m_pChart->GetLegend()->SetUserPosition(CPoint(40,20));
	m_pChart->GetLegend()->SetFont(100,"Microsoft Sans Serif");
	m_pChart->GetLeftAxis()->GetLabel()->SetText("");

}
void CSpecView::OnViewMassChart() 
{
	m_bThermoChart=FALSE;
	m_bCalibration=FALSE;
	FormatChartToMassHist();
	RedrawChart();
	ResizeClient();
}

void CSpecView::OnUpdateViewMassChart(CCmdUI* pCmdUI) 
{	pCmdUI->SetCheck(!m_bThermoChart);}

void CSpecView::OnViewTemperatureChart() 
{
	m_bThermoChart=TRUE;
	m_bCalibration=FALSE;
	m_ThermoHist.FormatChartToThermoHist();
	ResizeClient();
}

void CSpecView::OnUpdateViewTemperatureChart(CCmdUI* pCmdUI) 
{	pCmdUI->SetCheck(m_bThermoChart);}


LRESULT CSpecView::OnThermoRecieveNewMessage(WPARAM WParam, LPARAM LParam)
{
	m_ThermoHist.RecieveNewMessage();
	return (LRESULT)0;
}

void CSpecView::OnTrStart() 
{HeaterCommands.CommandStart();}

void CSpecView::OnTrWait() 
{HeaterCommands.CommandWait();}

void CSpecView::OnTrWaitCont() 
{HeaterCommands.CommandWaitContinue();}

void CSpecView::OnTrContinue() 
{HeaterCommands.CommandContinue();}

void CSpecView::OnTrMainOff() 
{HeaterCommands.CommandMainOff();}

void CSpecView::OnTrPrime() 
{HeaterCommands.CommandPrime();}

void CSpecView::OnTrGo() 
{HeaterCommands.CommandGo();}

void CSpecView::OnUpdateTrGo(CCmdUI* pCmdUI) 
{pCmdUI->SetCheck(HeaterCommands.State==CmdGo);}

void CSpecView::OnUpdateTrMainoff(CCmdUI* pCmdUI) 
{pCmdUI->SetCheck(HeaterCommands.State==CmdMainOff);}

void CSpecView::OnUpdateTrPrime(CCmdUI* pCmdUI) 
{pCmdUI->SetCheck(HeaterCommands.State==CmdPrime);}

void CSpecView::OnUpdateTrStart(CCmdUI* pCmdUI) 
{pCmdUI->SetCheck(HeaterCommands.State==CmdStart);}

void CSpecView::OnUpdateTrWait(CCmdUI* pCmdUI) 
{pCmdUI->SetCheck(HeaterCommands.WaitState);}

void CSpecView::OnUpdateTrWaitCont(CCmdUI* pCmdUI) 
{pCmdUI->SetCheck(HeaterCommands.WaitState);}
