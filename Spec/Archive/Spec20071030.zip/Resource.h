//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Spec.rc
//
#define IDD_ABOUTBOX                    100
#define ID_INDICATOR_REF_TEMP           101
#define ID_INDICATOR_CUR_TEMP           102
#define ID_INDICATOR_REMAIN_TIME        103
#define IDR_MAINFRAME                   128
#define IDR_MSPTYPE                     129
#define ID_CHART                        130
#define IDC_CURSOR_DIVSIZE              130
#define ID_LIST                         131
#define IDD_CALIB_DLG                   131
#define IDC_CURSOR_GRAPH                133
#define IDD_MEASURING_OPT_DLG           136
#define IDD_HARDWARE_SETUP_DLG          137
#define IDD_APPEARANCE_SETUP_DLG        139
#define IDD_TR_SETTINGS_DLG             141
#define IDR_TOOLBAR_TR                  142
#define IDD_CONTROLLER_SETUP_DLG        144
#define IDC_BUTTON_CALIB_OK             1000
#define IDC_LIST_CALIB                  1002
#define IDC_STATIC_BUILD_DATE           1003
#define IDC_BUTTON_CALIB_CANCEL         1004
#define IDC_EDIT_MASS_START             1005
#define IDC_EDIT_MASS_STOP              1006
#define IDC_EDIT_MASS_STEP              1007
#define IDC_EDIT_MASS_SETUP_DELAY       1008
#define IDC_COMBO_INTEGRATION           1009
#define IDC_COMBO_RANGE                 1010
#define IDC_APPEARANCE_CALIB_CHART      1011
#define IDC_COMBO_SERIES1_TYPE          1012
#define IDC_COMBO_SERIES1_ELEMENT       1013
#define IDC_BUTTON_SERIES1_COLOR        1014
#define IDC_SLIDER_SERIES1_SIZE         1015
#define IDC_STATIC_SIZE                 1016
#define IDC_COMBO_SERIES2_TYPE          1017
#define IDC_COMBO_SERIES2_ELEMENT       1018
#define IDC_BUTTON_SERIES2_COLOR        1019
#define IDC_SLIDER_SERIES2_SIZE         1020
#define IDC_STATIC_SIZE2                1021
#define IDC_DATETIMEPICKER              1024
#define IDC_EDIT_PRIME                  1027
#define IDC_EDIT_BETA_PLUS              1028
#define IDC_EDIT_T1                     1029
#define IDC_EDIT_BETA_MINUS             1030
#define IDC_EDIT_DWELL1                 1031
#define IDC_EDIT_T2                     1032
#define IDC_EDIT_DWELL2                 1033
#define IDC_CHECK_REPEATE               1034
#define IDC_EDIT_HEATING_RATE           1035
#define IDC_EDIT_COOLING_RATE           1036
#define IDC_EDIT_COLD_LEAD              1037
#define IDC_EDIT_COUPLE_FILE            1038
#define IDC_BUTTON_BROWSE_COUPLECALIB   1039
#define IDC_BUTTON_TR_SAVE              1040
#define IDC_BUTTON_TR_LOAD              1041
#define IDC_BUTTON_ADVANCED_OPTIONS     1042
#define IDC_EDIT_COM_PORT_NAME          1043
#define IDC_EDIT_KP                     1044
#define IDC_EDIT_KI                     1045
#define IDC_EDIT_KD                     1046
#define IDC_BUTTON_PID_COEF_LOAD        1047
#define IDC_STATIC_VP                   1048
#define IDC_STATIC_VI                   1049
#define IDC_STATIC_VD                   1050
#define IDC_STATIC_OUTPUT               1051
#define IDC_BUTTON_COM_RECONNECT        1052
#define ID_SETTINGS_HARDWARE            32771
#define ID_VIEW_MASSES                  32772
#define ID_SETTINGS_CALIBRATION         32774
#define ID_BUTTON_START                 32777
#define ID_BUTTON_STOP                  32778
#define ID_SETTINGS_MEASURINGOPTIONS    32780
#define ID_SETTINGS_APPEARANCE          32781
#define IDM_FILE_SAVEAS_EASYPLOT        32782
#define ID_TR_TRSETTINGS                32783
#define ID_TR_START                     32784
#define ID_TR_PRIME                     32785
#define ID_TR_WAIT                      32786
#define ID_TR_CONTINUE                  32787
#define ID_TR_MAINOFF                   32788
#define ID_TR_WAIT_CONT                 32790
#define ID__TR_GO                       32791
#define ID_TR_GO                        32797
#define ID_VIEW_TEMPERATURECHART        32799
#define ID_VIEW_MASSCHART               32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
