// AdcDacDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Spec.h"
#include "AdcDacDlg.h"
#include "Functions.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdcDacDlg dialog


CAdcDacDlg::CAdcDacDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdcDacDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdcDacDlg)
	//}}AFX_DATA_INIT
}


void CAdcDacDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdcDacDlg)
	DDX_Control(pDX, IDC_STATIC_AVER_ADC2, m_StaticAverAdc2);
	DDX_Control(pDX, IDC_STATIC_AVER_ADC3, m_StaticAverAdc3);
	DDX_Control(pDX, IDC_STATIC_AVER_ADC1, m_StaticAverAdc1);
	DDX_Control(pDX, IDC_STATIC_AVER_ADC0, m_StaticAverAdc0);
	DDX_Control(pDX, IDC_STATIC_ADC3, m_StaticAdc3);
	DDX_Control(pDX, IDC_STATIC_ADC2, m_StaticAdc2);
	DDX_Control(pDX, IDC_STATIC_ADC1, m_StaticAdc1);
	DDX_Control(pDX, IDC_STATIC_ADC0, m_StaticAdc0);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdcDacDlg, CDialog)
	//{{AFX_MSG_MAP(CAdcDacDlg)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_COM_EVENT, OnSerialLinkEvent)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdcDacDlg message handlers

BOOL CAdcDacDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	theApp.m_SerialLink.m_Pool.RegisterMsgReception(GetSafeHwnd());
	SetTimer(TIMER_POLL_SERIAL,500,NULL);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAdcDacDlg::OnDestroy() 
{
	theApp.m_SerialLink.m_Pool.UnRegisterMsgReception(GetSafeHwnd());
	CDialog::OnDestroy();
}

LRESULT CAdcDacDlg::OnSerialLinkEvent(WPARAM WParam, LPARAM LParam)
{
	int MsgType=HIWORD(LParam);
	BYTE Cmd=(BYTE)LOWORD(LParam);
	int AdcVal, Channel;
	CStatic* pStaticAdc[]={&m_StaticAdc0,&m_StaticAdc1,&m_StaticAdc2,&m_StaticAdc3};
	CStatic* pStaticAverAdc[]={&m_StaticAverAdc0,&m_StaticAverAdc1,&m_StaticAverAdc2,&m_StaticAverAdc3};
	static int NSample[4]={0,0,0,0},NAverage[4]={0,0,0,0}, 
		SumSample[4]={0,0,0,0}, SumAverage[4]={0,0,0,0};
	static double DNSample[4]={0,0,0,0}, DNAverage[4]={0,0,0,0};

	if((Cmd==CMD_GET_EXT_ADC || Cmd==CMD_GET_AVERAGED_ADC)&& MsgType==SERIAL_SYNC_MSG)
	{
		ComMsg msg=theApp.m_SerialLink.m_Pool.GetMsg(WParam);
		AdcVal=BytesToShort(msg.Buf[2],msg.Buf[3]);
		Channel=msg.Buf[1];
		if((Channel<0)||(Channel>3))
			return (LRESULT)0;
		char ch[30];
		double delta, sigma;
		if(Cmd==CMD_GET_EXT_ADC)
		{
			NSample[Channel]++;
			SumSample[Channel]+=AdcVal;
			delta=AdcVal-SumSample[Channel]/(double)NSample[Channel];
			DNSample[Channel]+=delta*delta;
			sigma=sqrt(DNSample[Channel]/NSample[Channel]);

		}
		else
		{
			NAverage[Channel]++;
			SumAverage[Channel]+=AdcVal;
			delta=AdcVal-SumAverage[Channel]/(double)NAverage[Channel];
			DNAverage[Channel]+=delta*delta;
			sigma=sqrt(DNAverage[Channel]/NAverage[Channel]);
		}
		double U,I;
		switch(Channel)
		{
		case 1:
			I=BytesToShort(msg.Buf[2],msg.Buf[3])*(4.096/16384.)*(25./2.5); //� �������
			sprintf(ch,"%4d, %2.1fA",AdcVal,I);
			break;
		case 2:
			U=BytesToShort(msg.Buf[2],msg.Buf[3])*(4.096/16384.)*(25./2.5); //� �������
			sprintf(ch,"%4d, %2.1f�",AdcVal,U);
			break;
		default:
			sprintf(ch,"%4d",AdcVal);
		}
		if(Cmd==CMD_GET_EXT_ADC)
			pStaticAdc[Channel]->SetWindowText(ch);
		else
			pStaticAverAdc[Channel]->SetWindowText(ch);
	}
	else if(MsgType==SERIAL_ERROR_COM_FAILED || MsgType==SERIAL_ERROR_TIMEOUT || MsgType==SERIAL_ASYNC_MSG)
	{
		for(Channel=0;Channel<4;Channel++)
		{
			pStaticAdc[Channel]->SetWindowText("...");
			pStaticAverAdc[Channel]->SetWindowText("...");
		}

	}
	return (LRESULT)0;
}

void CAdcDacDlg::OnTimer(UINT nIDEvent) 
{
	switch(nIDEvent)
	{
		case TIMER_POLL_SERIAL:
		{
			ComMsg msg;
			msg.Buf[0]=CMD_GET_EXT_ADC;
			msg.Buf[1]=0;
			msg.MsgSize=2;
			msg.WaitForReply=true;
			theApp.m_SerialLink.SendComMessage(msg);
			msg.Buf[1]=1;
			theApp.m_SerialLink.SendComMessage(msg);
			msg.Buf[1]=2;
			theApp.m_SerialLink.SendComMessage(msg);
			msg.Buf[1]=3;
			theApp.m_SerialLink.SendComMessage(msg);
			msg.Buf[0]=CMD_GET_AVERAGED_ADC;
			msg.Buf[1]=0;
			theApp.m_SerialLink.SendComMessage(msg);
			msg.Buf[1]=1;
			theApp.m_SerialLink.SendComMessage(msg);
			msg.Buf[1]=2;
			theApp.m_SerialLink.SendComMessage(msg);
			msg.Buf[1]=3;
			theApp.m_SerialLink.SendComMessage(msg);

			break;
		}
	}	
	CDialog::OnTimer(nIDEvent);
}
