#include "stdafx.h"
#include "Spec.h"
#include "CalibDlg.h"
#include "CamacUnits.h"
#include "VCMCDM.h"
#include "LogToFile.h"
#include "Threads.h"

#define FromAdcCodeToV(Code) ((022000-Code/(1<<theApp.Ini.AdcIntegration))/(1.+15*theApp.Ini.AdcRange)*0.001)

UINT CalibThread(LPVOID pParam)
{
	CCalibDlg *pCalibDlg=(CCalibDlg *)pParam;

	//Reading the INI file in the current folder:
	const int CrateN=GetPrivateProfileInt("CAMAC", "CrateNumber", 0,theApp.m_psIniFileName);
	const int DacN=GetPrivateProfileInt("CAMAC", "DacPosition", 1,theApp.m_psIniFileName);
	const int AdcN=GetPrivateProfileInt("CAMAC", "AdcPosition", 1,theApp.m_psIniFileName);
	int AdcValue=0;
	double Mass;

	#ifndef SIMULATION
	Camac_EnableMessage(FALSE); //camac driver won't display MessageBoxes
	Camac_Reset(CrateN);
	Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_WRITE_CONFIG_F, (theApp.Ini.AdcRange<<3)|theApp.Ini.AdcIntegration);
	Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_RESET_LAM_F, 0);
	#endif

	while(pCalibDlg->m_bMeasureStart)
	{
		for(Mass=theApp.Ini.CalibMassStart; Mass<=theApp.Ini.CalibMassStop && pCalibDlg->m_bMeasureStart; Mass+=theApp.Ini.CalibMassStep)
		{
			#ifndef SIMULATION
			double Volt=theApp.m_pMassCalibDoc->VoltageByMass(Mass);
			int Code=ToDac12Code(max(0,Volt));
			Camac_WriteWord(CrateN, DacN, 0, DAC_WRITE, Code);
			#endif
			Sleep(theApp.Ini.MassSetupDelay*1000);
			#ifndef SIMULATION
			Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_START_F, 0);
			Sleep(5*(1<<theApp.Ini.AdcIntegration)-5);
			int Wait;
			for(Wait=0; Wait<50; Wait++)
			{
				Camac_WriteWord(CrateN, AdcN, ADC_A, ADC_TEST_LAM_F, 0);
				if(Camac_q())
					break;
				Sleep(1);
			}
			if(Wait==50)
				Msg("Failed wait for ADC LAM");
			AdcValue=Camac_ReadLong(CrateN, AdcN, ADC_A, ADC_READ_VOLTAGE_F);
			#else
			AdcValue=abs(AdcValue+rand()*1000/RAND_MAX-550);
			#endif
			CalibPostNewPoint(Mass,FromAdcCodeToV(AdcValue),pCalibDlg);
		}
		if(Mass>theApp.Ini.CalibMassStop)
		{
			CalibPostEndSweep(pCalibDlg);
		}
	}
	PostMessage(pCalibDlg->GetSafeHwnd(),WM_NEW_CALIB_MSG,0,0);
	return 0;
}

void CalibPostNewPoint(double Mass, double Voltage, CCalibDlg* pCalibDlg)
{
	CMassCalibMsg CalibMsg;
	CalibMsg.Action=CalibMsg.eNewPoint;
	CalibMsg.Mass=Mass;
	CalibMsg.Voltage=Voltage;
	pCalibDlg->m_CalibMsgQueue.Push(CalibMsg);
	PostMessage(pCalibDlg->GetSafeHwnd(),WM_NEW_CALIB_MSG,1,0);
}

void CalibPostEndSweep(CCalibDlg* pCalibDlg)
{
	CMassCalibMsg CalibMsg={CMassCalibMsg::eEndSweep,0,0};
	pCalibDlg->m_CalibMsgQueue.Push(CalibMsg);
	PostMessage(pCalibDlg->GetSafeHwnd(),WM_NEW_CALIB_MSG,1,0);
}
