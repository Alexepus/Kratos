class CMainFrame;
BOOL WindowSaveAsOpen(CMainFrame* pMainFrame);