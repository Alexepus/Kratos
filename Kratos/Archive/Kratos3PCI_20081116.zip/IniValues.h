#ifndef _INIVALUES_H_
#define _INIVALUES_H_

class ValueSvLd
{
	//friend class IniValues;
	char *m_Section;
	char *m_Key;
	char *m_IniFileName;
public:
	enum ValType{t_str=1, t_int, t_double} Type;
	char *DefStr;
	double DefDouble;
	int DefInt;
	CString *sVal; //Read/Write length=MAX_PATH
	double dVal;
	int iVal;
	ValueSvLd(){m_Section=m_Key=DefStr=m_IniFileName=NULL;sVal=NULL; Type=(ValType)0;};
	void Describe(LPCTSTR DefaultVal, LPCTSTR Section, LPCTSTR Key, LPCTSTR IniFileName);
	void Describe(int DefaultVal,LPCTSTR Section, LPCTSTR Key, LPCTSTR IniFileName);
	void Describe(double DefaultVal,LPCTSTR Section, LPCTSTR Key, LPCTSTR IniFileName);
	~ValueSvLd();
	void Read();
	void Write();
	ValueSvLd& operator = (char *str) {if(Type==t_str) *sVal=str; return *this;};
	//operator = (ValueSvLd *pV, int val) {iVal=val;};
	//operator = (int &val, ValueSvLd *pV) {val=iVal;};
	//operator = (ValueSvLd *pV, double val) {dVal=val;};
	//operator = (double &val, ValueSvLd *pV) {val=dVal;};


};
	//char * operator = (char *str, ValueSvLd& V) {if(V.Type==ValueSvLd::t_str) strcpy(str, (LPCSTR)*V.sVal); return str;};

class IniValues
{
public:
	char IniFileName[MAX_PATH];
	IniValues();

//Data members
	ValueSvLd ProjectFile[4];
	ValueSvLd OriginFile;
	ValueSvLd EasyPlotFile;
	ValueSvLd HighPressureMode;
	ValueSvLd RetardCalibration;
};
#endif