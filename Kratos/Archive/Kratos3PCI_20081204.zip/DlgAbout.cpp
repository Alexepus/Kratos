// DlgAbout.cpp : implementation file
//

#include "stdafx.h"
#include "prognew.h"
#include "DlgAbout.h"
#include "ProgNew.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CProgNewApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CDlgAbout dialog


CDlgAbout::CDlgAbout(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAbout::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgAbout)
	m_StaticBuildDate = _T("");
	//}}AFX_DATA_INIT
}


void CDlgAbout::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAbout)
	DDX_Text(pDX, IDC_STATIC_BUILD_DATE, m_StaticBuildDate);
	DDX_Text(pDX, IDC_STATIC_MODE, m_StaticMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAbout, CDialog)
	//{{AFX_MSG_MAP(CDlgAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAbout message handlers

BOOL CDlgAbout::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	char *Date=__DATE__;
	char *Time=__TIME__;
	m_StaticBuildDate.Format("%s %s", Date, Time);
	if(!theApp.Ini.HighPressureMode.iVal)
		m_StaticMode="(KRATOS Mode)";
	else
		m_StaticMode="(High Pressure Mode)";
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
