#if !defined(AFX_BIGCLIENT_H__7F5E5186_75D1_11D5_9A4B_008048FD9845__INCLUDED_)
#define AFX_BIGCLIENT_H__7F5E5186_75D1_11D5_9A4B_008048FD9845__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// BigClient.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBigClient window
/*
class CBigClient : public CWnd
{
// Construction
public:
	CBigClient();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBigClient)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBigClient();

	// Generated message map functions
protected:
	//{{AFX_MSG(CBigClient)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
*/
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BIGCLIENT_H__7F5E5186_75D1_11D5_9A4B_008048FD9845__INCLUDED_)
