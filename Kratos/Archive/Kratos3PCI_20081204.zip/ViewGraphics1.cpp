// ViewGraphics1.cpp : implementation file
//

#include "stdafx.h"
#include "ProgNew.h"
//#include "ViewGraphics1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewGraphics

CViewGraphics::CViewGraphics()
{
}

CViewGraphics::~CViewGraphics()
{
}


BEGIN_MESSAGE_MAP(CViewGraphics, CWnd)
	//{{AFX_MSG_MAP(CViewGraphics)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CViewGraphics message handlers
