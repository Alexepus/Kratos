/*
#include "stdafx.h"
#include <string.h>
#include <stdio.h>

#include "ProgNew.h"
#include "Region.h"
//#include "function.h"
#include "TitleXWnd.h"
#include "DlgKEEnd.h"
#include "BigClientWnd.h"
#include "HideWnd.h"
//#include "Region.h"
#include "DialogParamRegion.h"
#include "ListRegionWnd.h"
#include "function.h"
#include "RegionWnd.h"
#include "OpenSaveFun.h"
#include "MainFrame.h"
*/
//#include "stdafx.h"
#include <string.h>
#include "ProgNew.h"
#include "TitleXWnd.h"
#include "Region.h"
#include "DialogParamRegion.h"
#include "function.h"