extern int DacData[16];
void LoadDac(BYTE Channel, UINT Val);
void ConfigDac(void);
