extern UINT MaxHeaterI;
extern UINT MaxHeaterU;
extern UINT MaxHeaterP;
extern ULONG_UNION MaxHeaterISoft;
extern UINT DacData0Max;

extern BYTE MaxHeaterIGuard;
extern BYTE MaxHeaterUGuard;
extern BYTE MaxHeaterPGuard;
extern BYTE MaxHeaterISoftCount;

void Limiter(void);
